import sys
import psutil
import os
import signal
import time

def layer1_method1(pid):
    try:
        p = psutil.Process(pid)
        # Try to terminate gracefully first
        p.terminate()
        try:
            p.wait(timeout=3)  # Wait 3 seconds for graceful exit
            return 0  # Success
        except psutil.TimeoutExpired:
            # Force kill if still alive
            if os.name == "nt":
                # Windows force kill
                os.system(f"taskkill /PID {pid} /F >nul 2>&1")
            else:
                # Unix force kill
                os.kill(pid, signal.SIGKILL)
            time.sleep(1)
            if not psutil.pid_exists(pid):
                return 0
            else:
                return 1
    except Exception:
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except:
        sys.exit(1)
    sys.exit(layer1_method1(pid))
import sys
import psutil
import os
import signal
import time

def layer1_method1(pid):
    print(f"[layer1_method1] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method1] Process found: {p.name()} (PID {pid})")
        # Try graceful terminate
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method1] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method1] Graceful terminate timed out, trying force kill...")
            if os.name == "nt":
                # Windows force kill
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method1] Force kill command succeeded.")
                else:
                    print("[layer1_method1] Force kill command failed.")
            else:
                # Unix force kill
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method1] Sent SIGKILL.")
            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method1] Process killed successfully.")
                return 0
            else:
                print("[layer1_method1] Process still alive after force kill.")
                return 1
    except psutil.NoSuchProcess:
        print("[layer1_method1] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method1] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method1] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method1] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method1(pid)
    sys.exit(exit_code)
