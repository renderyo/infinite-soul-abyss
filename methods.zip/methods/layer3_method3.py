import os
import sys
import subprocess
import psutil
import time
import ctypes
import random
import string
from threading import Thread

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll

THREAD_SUSPEND_RESUME = 0x0002
PROCESS_TERMINATE = 0x0001

def open_thread(tid):
    return kernel32.OpenThread(THREAD_SUSPEND_RESUME, False, tid)

def suspend_thread(tid):
    handle = open_thread(tid)
    if handle:
        kernel32.SuspendThread(handle)
        kernel32.CloseHandle(handle)

def resume_thread(tid):
    handle = open_thread(tid)
    if handle:
        kernel32.ResumeThread(handle)
        kernel32.CloseHandle(handle)

def aggressive_suspend_resume(pid, cycles=5, delay=0.5):
    try:
        proc = psutil.Process(pid)
        for _ in range(cycles):
            for thread in proc.threads():
                suspend_thread(thread.id)
            time.sleep(delay)
            for thread in proc.threads():
                resume_thread(thread.id)
            time.sleep(delay)
        return True
    except Exception:
        return False

def nt_terminate_process(pid):
    # Low-level termination using NtTerminateProcess
    PROCESS_ALL_ACCESS = 0x1F0FFF
    handle = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not handle:
        return False
    status = ntdll.NtTerminateProcess(handle, 0)
    kernel32.CloseHandle(handle)
    return status == 0

def rename_executable_repeated(proc, attempts=3):
    try:
        exe_path = proc.exe()
        dir_name, base_name = os.path.split(exe_path)
        for _ in range(attempts):
            suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
            new_name = f"_{base_name}_{suffix}.disabled"
            new_path = os.path.join(dir_name, new_name)
            if not os.path.exists(new_path):
                os.rename(exe_path, new_path)
                time.sleep(0.5)
        return True
    except Exception:
        return False

def forcibly_close_handles_repeated(pid, repeats=3):
    for _ in range(repeats):
        try:
            subprocess.run(['handle.exe', '-p', str(pid), '-c', 'all', '-y'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            time.sleep(0.5)
        except Exception:
            pass

def kill_child_processes(pid):
    try:
        proc = psutil.Process(pid)
        children = proc.children(recursive=True)
        for child in children:
            try:
                child.kill()
            except Exception:
                pass
        return True
    except Exception:
        return False

def mild_executable_corruption(proc):
    try:
        exe_path = proc.exe()
        with open(exe_path, "r+b") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            # Modify a small chunk at a random offset near the end
            offset = max(size - 1024, 0)
            f.seek(offset)
            data = f.read(16)
            f.seek(offset)
            corrupted = bytes(b ^ 0xFF for b in data)
            f.write(corrupted)
        return True
    except Exception:
        return False

def flood_process_with_events(pid, count=10):
    # Dummy placeholder for flooding messages or events
    # Real implementation would require Windows hooks or sending window messages.
    # Here, just a stub for conceptual completeness.
    for _ in range(count):
        time.sleep(0.1)
    return True

def psutil_terminate(pid):
    try:
        proc = psutil.Process(pid)
        proc.terminate()
        proc.wait(timeout=5)
        return True
    except Exception:
        return False

def main():
    if len(sys.argv) < 2:
        print("Usage: python layer3_method2.py <PID>")
        sys.exit(1)

    pid = int(sys.argv[1])

    if not psutil.pid_exists(pid):
        print(f"Process {pid} does not exist.")
        sys.exit(1)

    proc = psutil.Process(pid)
    proc_name = proc.name()

    print(f"[death] Layer3_Method2: Initiating ultra-powerful termination on PID {pid} ({proc_name})")

    # Step 1: Kill child processes aggressively
    print("[*] Killing child processes...")
    kill_child_processes(pid)

    # Step 2: Aggressive suspend/resume cycles
    print("[*] Aggressively suspending and resuming threads...")
    aggressive_suspend_resume(pid, cycles=7, delay=0.3)

    # Step 3: NtTerminateProcess call
    print("[*] Calling low-level NtTerminateProcess...")
    nt_terminate_process(pid)
    time.sleep(1)
    if not psutil.pid_exists(pid):
        print("[+] Process terminated by NtTerminateProcess.")
        sys.exit(0)

    # Step 4: Repeated executable rename
    print("[*] Renaming executable multiple times...")
    rename_executable_repeated(proc)

    # Step 5: Forcibly close handles multiple times
    print("[*] Forcibly closing handles with handle.exe (if available)...")
    forcibly_close_handles_repeated(pid)

    # Step 6: Mild executable corruption (just a nudge)
    print("[*] Mildly corrupting executable to prevent restart...")
    mild_executable_corruption(proc)

    # Step 7: Flood process with dummy events/signals
    print("[*] Flooding process with dummy events...")
    flood_process_with_events(pid)

    # Step 8: Final psutil termination fallback
    print("[*] Final psutil termination attempt...")
    psutil_terminate(pid)
    time.sleep(1)

    if not psutil.pid_exists(pid):
        print("[!] Process terminated successfully with ultra-power method.")
        sys.exit(0)

    print("[bruh] Failed to terminate the process. Manual intervention may be required.")

if __name__ == "__main__":
    main()
