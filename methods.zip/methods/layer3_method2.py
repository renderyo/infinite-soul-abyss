import sys
import psutil
import subprocess
import ctypes
import time
import os

import win32com.client  # pip install pywin32

# Windows API constants and functions
PROCESS_ALL_ACCESS = 0x1F0FFF
PROCESS_TERMINATE = 0x0001
PROCESS_SUSPEND_RESUME = 0x0800
kernel32 = ctypes.windll.kernel32

def open_process(pid, access=PROCESS_ALL_ACCESS):
    handle = kernel32.OpenProcess(access, False, pid)
    return handle

def close_handle(handle):
    kernel32.CloseHandle(handle)

def terminate_process_handle(handle):
    return kernel32.TerminateProcess(handle, -1)

def suspend_process(pid):
    # Suspend all threads of the process
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            th_handle = kernel32.OpenThread(0x0002, False, thread.id)  # THREAD_SUSPEND_RESUME = 0x0002
            if th_handle:
                kernel32.SuspendThread(th_handle)
                kernel32.CloseHandle(th_handle)
        return True
    except Exception:
        return False

def resume_process(pid):
    # Resume all threads of the process
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            th_handle = kernel32.OpenThread(0x0002, False, thread.id)
            if th_handle:
                kernel32.ResumeThread(th_handle)
                kernel32.CloseHandle(th_handle)
        return True
    except Exception:
        return False

def kill_with_taskkill(pid):
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        return not psutil.pid_exists(pid)
    except Exception:
        return False

def kill_with_wmic(proc_name):
    try:
        wmi = win32com.client.GetObject("winmgmts:")
        for p in wmi.InstancesOf("Win32_Process"):
            if p.Name.lower() == proc_name.lower():
                p.Terminate()
        time.sleep(2)
        return True
    except Exception:
        return False

def powershell_force_kill(pid):
    try:
        # Use powershell Stop-Process with force and error action stop
        cmd = f"Stop-Process -Id {pid} -Force -ErrorAction Stop"
        subprocess.run(["powershell", "-Command", cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        return not psutil.pid_exists(pid)
    except Exception:
        return False

def inject_terminate_thread(pid):
    # Attempt to inject a thread into process to call TerminateProcess inside
    # This is advanced and may fail silently; best effort.
    PROCESS_CREATE_THREAD = 0x0002
    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_VM_OPERATION = 0x0008
    PROCESS_VM_WRITE = 0x0020
    PROCESS_VM_READ = 0x0010

    PAGE_EXECUTE_READWRITE = 0x40
    MEM_COMMIT = 0x1000
    MEM_RESERVE = 0x2000

    kernel32 = ctypes.windll.kernel32
    pid = int(pid)
    handle = kernel32.OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, False, pid)
    if not handle:
        return False

    # Define TerminateProcess function address
    term_proc_addr = kernel32.GetProcAddress(kernel32._handle, b"TerminateProcess")
    if not term_proc_addr:
        kernel32.CloseHandle(handle)
        return False

    # Allocate memory in target process
    arg_address = kernel32.VirtualAllocEx(handle, 0, 4, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE)
    if not arg_address:
        kernel32.CloseHandle(handle)
        return False

    # Write exit code to allocated memory
    exit_code = ctypes.c_int(-1)
    written = ctypes.c_size_t()
    if not kernel32.WriteProcessMemory(handle, arg_address, ctypes.byref(exit_code), ctypes.sizeof(exit_code), ctypes.byref(written)):
        kernel32.VirtualFreeEx(handle, arg_address, 0, 0x8000)
        kernel32.CloseHandle(handle)
        return False

    # Create remote thread calling TerminateProcess(handle, -1)
    thread_id = ctypes.c_ulong(0)
    if not kernel32.CreateRemoteThread(handle, None, 0, term_proc_addr, handle, 0, ctypes.byref(thread_id)):
        kernel32.VirtualFreeEx(handle, arg_address, 0, 0x8000)
        kernel32.CloseHandle(handle)
        return False

    kernel32.CloseHandle(handle)
    time.sleep(3)
    return not psutil.pid_exists(pid)

def corrupt_process_environment(pid):
    # Rename the executable to confuse protection
    try:
        proc = psutil.Process(pid)
        exe = proc.exe()
        if os.path.exists(exe):
            new_name = exe + ".corrupt"
            try:
                os.rename(exe, new_name)
                time.sleep(1)
                os.rename(new_name, exe)
                return True
            except Exception:
                pass
        return False
    except Exception:
        return False

def aggressive_suspend_and_kill(pid):
    suspend_process(pid)
    kill_with_taskkill(pid)
    resume_process(pid)
    time.sleep(2)
    return not psutil.pid_exists(pid)

def main():
    if len(sys.argv) < 2:
        print("Usage: layer3_method1.py <PID>")
        sys.exit(1)

    pid = int(sys.argv[1])

    if not psutil.pid_exists(pid):
        print(f"Process {pid} does not exist.")
        sys.exit(1)

    proc = psutil.Process(pid)
    proc_name = proc.name()

    print(f"[!] Attempting POWERFUL termination on PID {pid} ({proc_name})...\n")

    attempts = [
        ("Graceful terminate", lambda p: p.terminate() or p.wait(timeout=5)),
        ("Forceful kill", lambda p: p.kill() or p.wait(timeout=5)),
        ("Taskkill /F /T", lambda p: kill_with_taskkill(p.pid)),
        ("WMI Termination", lambda p: kill_with_wmic(p.name())),
        ("PowerShell force kill", lambda p: powershell_force_kill(p.pid)),
        ("Inject TerminateProcess thread", lambda p: inject_terminate_thread(p.pid)),
        ("Corrupt exe name", lambda p: corrupt_process_environment(p.pid)),
        ("Aggressive suspend and kill", lambda p: aggressive_suspend_and_kill(p.pid)),
    ]

    for name, func in attempts:
        print(f"[+] {name}...")
        try:
            func(proc)
        except Exception as e:
            print(f"    Exception during {name}: {e}")

        if not psutil.pid_exists(pid):
            print(f" Process terminated successfully with: {name}")
            sys.exit(0)
        else:
            print(f"    {name} failed or process still alive.")

    print(" Failed to terminate the process after all aggressive attempts.")
    sys.exit(1)

if __name__ == "__main__":
    main()
