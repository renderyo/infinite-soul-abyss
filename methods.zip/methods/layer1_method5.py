import sys
import psutil
import os
import signal
import time
import threading

def cpu_stress(duration_sec=2):
    print("[layer1_method5] Starting CPU stress...")
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        # Busy loop
        for i in range(10000):
            _ = i*i

def dummy_io(p):
    print("[layer1_method5] Doing dummy I/O tampering...")
    try:
        # Try opening and closing the executable file handle rapidly
        exe_path = p.exe()
        for _ in range(3):
            with open(exe_path, 'rb') as f:
                f.read(10)
            time.sleep(0.1)
        print("[layer1_method5] Dummy I/O done.")
    except Exception as e:
        print(f"[layer1_method5] Dummy I/O failed: {e}")

def layer1_method5(pid):
    print(f"[layer1_method5] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method5] Process found: {p.name()} (PID {pid})")

        # Aggressive suspend/resume cycles
        try:
            for _ in range(10):
                p.suspend()
                print("[layer1_method5] Process suspended (tampering).")
                time.sleep(0.2)
                p.resume()
                print("[layer1_method5] Process resumed (tampering).")
                time.sleep(0.2)
        except psutil.AccessDenied:
            print("[layer1_method5] Access denied: cannot suspend/resume process.")
        except Exception as e:
            print(f"[layer1_method5] Tampering suspend/resume failed: {e}")

        # Rapid priority toggling including realtime if possible
        try:
            priorities = []
            if os.name == "nt":
                # Windows priority classes from lowest to highest
                priorities = [
                    psutil.IDLE_PRIORITY_CLASS,
                    psutil.BELOW_NORMAL_PRIORITY_CLASS,
                    psutil.NORMAL_PRIORITY_CLASS,
                    psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                    psutil.HIGH_PRIORITY_CLASS,
                    psutil.REALTIME_PRIORITY_CLASS
                ]
            else:
                # Unix nice values from lowest (19) to highest (-20)
                priorities = [19, 10, 0, -10, -15, -20]

            for prio in priorities:
                try:
                    p.nice(prio)
                    print(f"[layer1_method5] Set priority to {prio}.")
                    time.sleep(0.3)
                except Exception as e:
                    print(f"[layer1_method5] Failed to set priority {prio}: {e}")
        except Exception as e:
            print(f"[layer1_method5] Priority tampering failed: {e}")

        # CPU stress in a separate thread to not block fully
        stress_thread = threading.Thread(target=cpu_stress, args=(2,))
        stress_thread.start()

        # Dummy I/O tampering
        dummy_io(p)

        stress_thread.join()

        # Terminate the process
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method5] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method5] Graceful terminate timed out, forcing kill...")

            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method5] Force kill succeeded.")
                else:
                    print("[layer1_method5] Force kill failed.")
            else:
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method5] Sent SIGKILL.")

            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method5] Process killed successfully.")
                return 0
            else:
                print("[layer1_method5] Process still alive after force kill.")
                return 1

    except psutil.NoSuchProcess:
        print("[layer1_method5] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method5] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method5] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method5] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method5(pid)
    sys.exit(exit_code)
