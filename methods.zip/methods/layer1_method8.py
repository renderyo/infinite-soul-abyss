import sys
import psutil
import os
import signal
import time
import threading
import random

def cpu_stress(duration_sec=7):
    print("[layer1_method8] Starting CPU stress...")
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        for i in range(20000):
            _ = i*i

def memory_stress(iterations=15, size_mb=40):
    print("[layer1_method8] Starting memory stress...")
    blocks = []
    for _ in range(iterations):
        try:
            blocks.append(bytearray(size_mb * 1024 * 1024))  # allocate size_mb MB
            time.sleep(0.3)
        except MemoryError:
            print("[layer1_method8] Memory allocation failed, stopping stress.")
            break
    blocks.clear()

def affinity_chaos(p, toggle_count=50):
    print("[layer1_method8] Starting CPU affinity chaos...")
    try:
        cpus = list(range(psutil.cpu_count()))
        for _ in range(toggle_count):
            new_affinity = random.sample(cpus, random.randint(1, len(cpus)))
            p.cpu_affinity(new_affinity)
            print(f"[layer1_method8] Set CPU affinity to: {new_affinity}")
            time.sleep(0.1)
    except Exception as e:
        print(f"[layer1_method8] Failed affinity chaos: {e}")

def dummy_io(p, attempts=30):
    print("[layer1_method8] Starting dummy I/O tampering...")
    try:
        exe_path = p.exe()
        for _ in range(attempts):
            try:
                with open(exe_path, 'rb') as f:
                    f.read(10)
                print("[layer1_method8] Opened and read from executable.")
                time.sleep(0.05)
            except Exception as e:
                print(f"[layer1_method8] File I/O error: {e}")
    except Exception as e:
        print(f"[layer1_method8] Cannot access executable path: {e}")

def thread_flooding(count=50):
    print("[layer1_method8] Starting simulated thread flooding...")

    def dummy_task():
        time.sleep(0.1)

    threads = []
    for _ in range(count):
        t = threading.Thread(target=dummy_task)
        t.start()
        threads.append(t)
        time.sleep(0.01)

    for t in threads:
        t.join()
    print("[layer1_method8] Thread flooding done.")

def insanity_suspend_resume(p, cycles=100):
    print("[layer1_method8] Starting extreme suspend/resume spam...")
    try:
        for _ in range(cycles):
            p.suspend()
            time.sleep(0.03)
            p.resume()
            time.sleep(0.03)
    except psutil.AccessDenied:
        print("[layer1_method8] Access denied: cannot suspend/resume process.")
    except Exception as e:
        print(f"[layer1_method8] Suspend/resume failed: {e}")

def priority_chaos(p, cycles=5):
    print("[layer1_method8] Starting priority chaos...")
    try:
        priorities = []
        if os.name == "nt":
            priorities = [
                psutil.IDLE_PRIORITY_CLASS,
                psutil.BELOW_NORMAL_PRIORITY_CLASS,
                psutil.NORMAL_PRIORITY_CLASS,
                psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                psutil.HIGH_PRIORITY_CLASS,
                psutil.REALTIME_PRIORITY_CLASS
            ]
        else:
            priorities = [19, 10, 0, -10, -15, -20]

        for _ in range(cycles):
            random.shuffle(priorities)
            for prio in priorities:
                try:
                    p.nice(prio)
                    print(f"[layer1_method8] Set priority to {prio}.")
                    time.sleep(0.1)
                except Exception as e:
                    print(f"[layer1_method8] Failed to set priority {prio}: {e}")
    except Exception as e:
        print(f"[layer1_method8] Priority chaos failed: {e}")

def repeated_terminate_kill(p, pid, attempts=5):
    print("[layer1_method8] Starting repeated termination attempts...")
    for attempt in range(attempts):
        print(f"[layer1_method8] Termination attempt {attempt+1}/{attempts}...")
        try:
            p.terminate()
        except Exception as e:
            print(f"[layer1_method8] Terminate failed: {e}")
        try:
            p.wait(timeout=2)
            print("[layer1_method8] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method8] Graceful terminate timed out, forcing kill...")
            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method8] Force kill succeeded.")
                else:
                    print("[layer1_method8] Force kill failed.")
            else:
                try:
                    os.kill(pid, signal.SIGKILL)
                    print("[layer1_method8] Sent SIGKILL.")
                except Exception as e:
                    print(f"[layer1_method8] SIGKILL failed: {e}")
            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method8] Process killed successfully.")
                return 0
            else:
                print("[layer1_method8] Process still alive after force kill.")
    print("[layer1_method8] Failed to terminate process after repeated attempts.")
    return 1

def layer1_method8(pid):
    print(f"[layer1_method8] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method8] Process found: {p.name()} (PID {pid})")

        # Extreme suspend/resume spam
        insanity_suspend_resume(p, cycles=100)

        # Priority chaos
        priority_chaos(p, cycles=8)

        # CPU affinity chaos (run in thread)
        affinity_thread = threading.Thread(target=affinity_chaos, args=(p, 50))
        affinity_thread.start()

        # Start multiple CPU stress threads
        cpu_threads = []
        for _ in range(10):
            t = threading.Thread(target=cpu_stress, args=(7,))
            t.start()
            cpu_threads.append(t)

        # Memory stress thread
        mem_thread = threading.Thread(target=memory_stress, args=(20, 50))
        mem_thread.start()

        # Dummy I/O tampering
        dummy_io(p, attempts=40)

        # Thread flooding
        thread_flooding(70)

        # Wait for stress threads
        affinity_thread.join()
        for t in cpu_threads:
            t.join()
        mem_thread.join()

        # Repeated termination attempts
        result = repeated_terminate_kill(p, pid, attempts=7)
        return result

    except psutil.NoSuchProcess:
        print("[layer1_method8] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method8] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method8] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method8] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method8(pid)
    sys.exit(exit_code)
