import ctypes
import sys
import psutil
import time
import random
import threading
from ctypes import wintypes

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll
user32 = ctypes.windll.user32

PROCESS_ALL_ACCESS = 0x001F0FFF

# NtTerminateProcess prototype
ntdll.NtTerminateProcess.restype = ctypes.c_ulong
ntdll.NtTerminateProcess.argtypes = [wintypes.HANDLE, ctypes.c_ulong]

# Function prototypes
OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [wintypes.HANDLE]
CloseHandle.restype = wintypes.BOOL

TerminateProcess = kernel32.TerminateProcess
TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
TerminateProcess.restype = wintypes.BOOL

SuspendThread = kernel32.SuspendThread
ResumeThread = kernel32.ResumeThread
OpenThread = kernel32.OpenThread
OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenThread.restype = wintypes.HANDLE
THREAD_SUSPEND_RESUME = 0x0002

SetPriorityClass = kernel32.SetPriorityClass
SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetPriorityClass.restype = wintypes.BOOL

VirtualAllocEx = kernel32.VirtualAllocEx
WriteProcessMemory = kernel32.WriteProcessMemory

MEM_COMMIT = 0x1000
PAGE_EXECUTE_READWRITE = 0x40

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_OPERATION = 0x0008
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_READ = 0x0010

def open_process(pid):
    handle = OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not handle:
        print(f"[layer2_method5] Failed to open process PID {pid}")
    return handle

def glitch_process(pid):
    print(f"[layer2_method5] Starting glitch sequence on PID {pid}")

    handle = open_process(pid)
    if not handle:
        return False

    # Change priority randomly multiple times
    priorities = [0x00000080, 0x00000040, 0x00000020, 0x00000100]  # IDLE, BELOW_NORMAL, NORMAL, ABOVE_NORMAL
    for _ in range(5):
        priority = random.choice(priorities)
        if SetPriorityClass(handle, priority):
            print(f"[layer2_method5] Changed process priority to {hex(priority)}")
        else:
            print("[layer2_method5] Failed to change priority")
        time.sleep(0.1)

    # Suspend and resume threads repeatedly
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            tid = thread.id
            th = OpenThread(THREAD_SUSPEND_RESUME, False, tid)
            if th:
                for _ in range(3):
                    SuspendThread(th)
                    time.sleep(0.05)
                    ResumeThread(th)
                    time.sleep(0.05)
                CloseHandle(th)
        print("[layer2_method5] Suspended/resumed threads glitch complete")
    except Exception as e:
        print(f"[layer2_method5] Error suspending/resuming threads: {e}")

    # Try renaming window title if exists (requires user32)
    def enum_windows_callback(hwnd, lParam):
        pid_ = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
        if pid_.value == pid:
            new_title = "GLITCHED_PROCESS_𓂀"
            user32.SetWindowTextW(hwnd, new_title)
            print("[layer2_method5] Changed window title to glitch text")
            return False  # stop enumerating windows
        return True

    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user32.EnumWindows(EnumWindowsProc(enum_windows_callback), 0)

    # Allocate and write some garbage data into process memory
    try:
        garbage = bytes([random.randint(0, 255) for _ in range(1024)])
        addr = VirtualAllocEx(handle, 0, len(garbage), MEM_COMMIT, PAGE_EXECUTE_READWRITE)
        if addr:
            written = ctypes.c_size_t()
            if WriteProcessMemory(handle, addr, garbage, len(garbage), ctypes.byref(written)):
                print(f"[layer2_method5] Injected {written.value} bytes of garbage into process memory")
            else:
                print("[layer2_method5] Failed to write garbage memory")
        else:
            print("[layer2_method5] Failed to allocate memory in process")
    except Exception as e:
        print(f"[layer2_method5] Error injecting garbage memory: {e}")

    CloseHandle(handle)
    print("[layer2_method5] Glitch sequence complete")
    return True

def force_nt_terminate_process(pid):
    print(f"[layer2_method5] Attempting NtTerminateProcess on PID {pid}")
    handle = open_process(pid)
    if not handle:
        return False

    status = ntdll.NtTerminateProcess(handle, 0)
    CloseHandle(handle)

    if status == 0:
        print("[layer2_method5] NtTerminateProcess succeeded")
        return True
    else:
        print(f"[layer2_method5] NtTerminateProcess failed with status 0x{status:X}")
        return False

def run(pid):
    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        print(f"[layer2_method5] Process {pid} not found.")
        return False

    if not proc.is_running():
        print(f"[layer2_method5] Process {pid} is not running.")
        return True

    glitch_process(pid)
    time.sleep(1)  # small delay before kill
    return force_nt_terminate_process(pid)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method5.py <pid>")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID.")
        sys.exit(1)

    success = run(pid)
    sys.exit(0 if success else 1)
