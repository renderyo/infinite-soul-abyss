import ctypes
import psutil
import win32api
import win32con
import win32process
import win32event
import win32security
import time
import random
import os

# Windows API imports
ntdll = ctypes.windll.ntdll
kernel32 = ctypes.windll.kernel32

SE_DEBUG_NAME = "SeDebugPrivilege"

def enable_privileges():
    try:
        hToken = win32security.OpenProcessToken(win32api.GetCurrentProcess(),
                                                win32con.TOKEN_ADJUST_PRIVILEGES | win32con.TOKEN_QUERY)
        privilege_id = win32security.LookupPrivilegeValue(None, SE_DEBUG_NAME)
        win32security.AdjustTokenPrivileges(hToken, False, [(privilege_id, win32con.SE_PRIVILEGE_ENABLED)])
    except Exception:
        pass  # Fail silently

def get_process_by_name(name):
    for proc in psutil.process_iter(['pid', 'name']):
        if name.lower() in proc.info['name'].lower():
            return proc
    return None

def terminate_process_native(pid):
    try:
        PROCESS_ALL = 0x1F0FFF
        handle = kernel32.OpenProcess(PROCESS_ALL, False, pid)
        if not handle:
            return False

        # Native NtTerminateProcess (unfiltered)
        status = ntdll.NtTerminateProcess(handle, 1)
        kernel32.CloseHandle(handle)
        return status == 0
    except Exception:
        return False

def suspend_process_threads(pid):
    try:
        hProcess = win32api.OpenProcess(win32con.PROCESS_ALL_ACCESS, False, pid)
        threads = win32process.EnumProcessThreads(pid)
        for thread_id in threads:
            try:
                hThread = win32api.OpenThread(win32con.THREAD_SUSPEND_RESUME, False, thread_id)
                kernel32.SuspendThread(hThread)
                kernel32.CloseHandle(hThread)
            except Exception:
                continue
        kernel32.CloseHandle(hProcess)
    except Exception:
        pass

def remote_exit_thread_injection(pid):
    try:
        PROCESS_ALL_ACCESS = 0x1F0FFF
        hProcess = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
        addr = kernel32.VirtualAllocEx(hProcess, 0, 1024, 0x1000 | 0x2000, 0x40)
        exit_func = kernel32.GetProcAddress(kernel32.GetModuleHandleA(b'kernel32.dll'), b'ExitProcess')
        thread_id = ctypes.c_ulong(0)
        if kernel32.CreateRemoteThread(hProcess, None, 0, exit_func, None, 0, ctypes.byref(thread_id)):
            kernel32.CloseHandle(hProcess)
            return True
        kernel32.CloseHandle(hProcess)
    except Exception:
        pass
    return False

def brother_termination(pid):
    # Super-aggressive combo of low and high-level
    result = terminate_process_native(pid)
    if not result:
        suspend_process_threads(pid)
        remote_exit_thread_injection(pid)
        kernel32.TerminateProcess(kernel32.OpenProcess(1, False, pid), 1)
    return True

def main():
    enable_privileges()

    proc_name = input("Target process name (e.g. notepad.exe): ").strip()
    proc = get_process_by_name(proc_name)

    if not proc:
        print("Process not found.")
        return

    pid = proc.pid
    print(f"[L6] Targeting PID {pid} ({proc_name}) with god termination...")

    success = terminate_process_native(pid)

    if not success:
        print(f"[L6] Primary method failed. Engaging brother termination.")
        brother_termination(pid)
    else:
        print("[L6] Terminated successfully via native kill.")

    time.sleep(1)
    if psutil.pid_exists(pid):
        print("[L6] Process survived. Reinforcing remote exit...")
        remote_exit_thread_injection(pid)

    time.sleep(1)
    if psutil.pid_exists(pid):
        print("[L6] Final attempt: raw TerminateProcess...")
        try:
            handle = kernel32.OpenProcess(1, False, pid)
            kernel32.TerminateProcess(handle, -1)
            kernel32.CloseHandle(handle)
        except Exception:
            pass

    if psutil.pid_exists(pid):
        print("[L6] Process still alive. This one’s extremely resilient.")
    else:
        print("[L6] Process successfully destroyed at final stage.")

if __name__ == "__main__":
    main()
