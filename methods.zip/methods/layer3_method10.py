import ctypes
import ctypes.wintypes as wintypes
import psutil
import sys
import time
import subprocess

# Windows constants
PROCESS_ALL_ACCESS = 0x1F0FFF
THREAD_SUSPEND_RESUME = 0x0002
THREAD_TERMINATE = 0x0001
MEM_RELEASE = 0x8000
PAGE_READWRITE = 0x04

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

TerminateProcess = kernel32.TerminateProcess
TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
TerminateProcess.restype = wintypes.BOOL

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [wintypes.HANDLE]
CloseHandle.restype = wintypes.BOOL

OpenThread = kernel32.OpenThread
OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenThread.restype = wintypes.HANDLE

SuspendThread = kernel32.SuspendThread
SuspendThread.argtypes = [wintypes.HANDLE]
SuspendThread.restype = wintypes.DWORD

ResumeThread = kernel32.ResumeThread
ResumeThread.argtypes = [wintypes.HANDLE]
ResumeThread.restype = wintypes.DWORD

TerminateThread = kernel32.TerminateThread
TerminateThread.argtypes = [wintypes.HANDLE, wintypes.DWORD]
TerminateThread.restype = wintypes.BOOL

VirtualFreeEx = kernel32.VirtualFreeEx
VirtualFreeEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD]
VirtualFreeEx.restype = wintypes.BOOL

NtTerminateProcess = ntdll.NtTerminateProcess
NtTerminateProcess.argtypes = [wintypes.HANDLE, wintypes.INT]
NtTerminateProcess.restype = wintypes.INT

def force_terminate_process(pid):
    print(f"[ISA][L3M10] Attempting to terminate PID {pid} aggressively.")

    # Open process handle
    process_handle = OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not process_handle:
        print(f"[ISA][L3M10] Failed to open process handle. Error code: {ctypes.get_last_error()}")
        return False

    # Attempt to suspend all threads
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            thread_id = thread.id
            thread_handle = OpenThread(THREAD_SUSPEND_RESUME | THREAD_TERMINATE, False, thread_id)
            if thread_handle:
                SuspendThread(thread_handle)
                TerminateThread(thread_handle, 1)
                CloseHandle(thread_handle)
                print(f"[ISA][L3M10] Suspended and terminated thread {thread_id}")
            else:
                print(f"[ISA][L3M10] Failed to open thread {thread_id}. Error: {ctypes.get_last_error()}")
    except Exception as e:
        print(f"[ISA][L3M10] Exception suspending threads: {e}")

    # Try to unmap memory regions forcibly (VERY aggressive)
    try:
        proc = psutil.Process(pid)
        for mem in proc.memory_maps():
            base_addr = int(mem.addr.split('-')[0], 16)
            size = int(mem.addr.split('-')[1], 16) - base_addr
            if size > 0:
                success = VirtualFreeEx(process_handle, ctypes.c_void_p(base_addr), size, MEM_RELEASE)
                print(f"[ISA][L3M10] VirtualFreeEx on {hex(base_addr)} size {size}: {'Success' if success else 'Fail'}")
    except Exception as e:
        print(f"[ISA][L3M10] Exception during memory unmapping: {e}")

    # Try TerminateProcess
    if TerminateProcess(process_handle, 1):
        print("[ISA][L3M10] TerminateProcess succeeded.")
        CloseHandle(process_handle)
        return True
    else:
        print(f"[ISA][L3M10] TerminateProcess failed. Error: {ctypes.get_last_error()}")

    # Try NtTerminateProcess (native API)
    status = NtTerminateProcess(process_handle, 1)
    if status == 0:
        print("[ISA][L3M10] NtTerminateProcess succeeded.")
        CloseHandle(process_handle)
        return True
    else:
        print(f"[ISA][L3M10] NtTerminateProcess failed with status: {status}")

    CloseHandle(process_handle)

    # Last resort: Use taskkill with force and PID
    print("[ISA][L3M10] Falling back to taskkill /F")
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/F", "/T"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("[ISA][L3M10] taskkill succeeded.")
        return True
    except Exception as e:
        print(f"[ISA][L3M10] taskkill failed: {e}")

    print("[ISA][L3M10] Failed to terminate the process with all methods.")
    return False

def main():
    if len(sys.argv) < 2:
        print("Usage: python layer3_method10.py <pid>")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID.")
        sys.exit(1)

    if not psutil.pid_exists(pid):
        print(f"Process with PID {pid} does not exist.")
        sys.exit(1)

    success = force_terminate_process(pid)
    if success:
        print("Method 10 succeeded in terminating the process.")
        sys.exit(0)
    else:
        print("Method 10 failed to terminate the process.")
        sys.exit(1)

if __name__ == "__main__":
    main()
