import ctypes
import os
import psutil
import sys

# Constants
PROCESS_TERMINATE = 0x0001
PROCESS_ALL_ACCESS = 0x1F0FFF
INVALID_HANDLE_VALUE = -1
KERNEL32 = ctypes.WinDLL("kernel32", use_last_error=True)
NTDLL = ctypes.WinDLL("ntdll", use_last_error=True)

def is_protected(pid):
    return pid in [0, 4] or pid == os.getpid()

def enable_privileges():
    import win32con
    import win32api
    import win32security

    hToken = win32security.OpenProcessToken(
        win32api.GetCurrentProcess(), win32con.TOKEN_ADJUST_PRIVILEGES | win32con.TOKEN_QUERY
    )
    privilege_id = win32security.LookupPrivilegeValue(None, win32con.SE_DEBUG_NAME)
    win32security.AdjustTokenPrivileges(hToken, 0, [(privilege_id, win32con.SE_PRIVILEGE_ENABLED)])

def terminate_with_ctypes(pid):
    handle = KERNEL32.OpenProcess(PROCESS_TERMINATE, False, pid)
    if handle:
        KERNEL32.TerminateProcess(handle, -1)
        KERNEL32.CloseHandle(handle)

def terminate_with_ntdll(pid):
    class OBJECT_ATTRIBUTES(ctypes.Structure):
        _fields_ = [("Length", ctypes.c_ulong),
                    ("RootDirectory", ctypes.c_void_p),
                    ("ObjectName", ctypes.c_void_p),
                    ("Attributes", ctypes.c_ulong),
                    ("SecurityDescriptor", ctypes.c_void_p),
                    ("SecurityQualityOfService", ctypes.c_void_p)]

    class CLIENT_ID(ctypes.Structure):
        _fields_ = [("UniqueProcess", ctypes.c_void_p),
                    ("UniqueThread", ctypes.c_void_p)]

    NtOpenProcess = NTDLL.NtOpenProcess
    NtOpenProcess.argtypes = [ctypes.POINTER(ctypes.c_void_p),
                              ctypes.c_ulong,
                              ctypes.POINTER(OBJECT_ATTRIBUTES),
                              ctypes.POINTER(CLIENT_ID)]
    NtOpenProcess.restype = ctypes.c_ulong

    NtTerminateProcess = NTDLL.NtTerminateProcess
    NtTerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    NtTerminateProcess.restype = ctypes.c_ulong

    oa = OBJECT_ATTRIBUTES()
    oa.Length = ctypes.sizeof(oa)
    cid = CLIENT_ID()
    cid.UniqueProcess = ctypes.c_void_p(pid)
    cid.UniqueThread = None
    phandle = ctypes.c_void_p()

    status = NtOpenProcess(ctypes.byref(phandle), PROCESS_ALL_ACCESS, ctypes.byref(oa), ctypes.byref(cid))
    if status == 0:
        NtTerminateProcess(phandle, 1)

def close_process_handles(pid):
    # Attempt to force close handles to degrade the target
    import win32api, win32con
    try:
        handle = win32api.OpenProcess(win32con.PROCESS_ALL_ACCESS, False, pid)
        win32api.TerminateProcess(handle, -1)
        win32api.CloseHandle(handle)
    except:
        pass

def destroy_process(pid):
    if is_protected(pid):
        print(f"[!] Skipping protected PID {pid}")
        return

    print(f"[+] Terminating PID {pid}...")

    try:
        proc = psutil.Process(pid)
        proc.terminate()
        proc.kill()
    except:
        pass

    try:
        terminate_with_ctypes(pid)
    except:
        pass

    try:
        terminate_with_ntdll(pid)
    except:
        pass

    try:
        close_process_handles(pid)
    except:
        pass

    print(f"[✓] Process {pid} handled.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python layer3_method9.py <PID>")
        sys.exit(1)

    try:
        enable_privileges()
    except:
        print("[!] Could not elevate privileges. Trying anyway.")

    target_pid = int(sys.argv[1])
    destroy_process(target_pid)
