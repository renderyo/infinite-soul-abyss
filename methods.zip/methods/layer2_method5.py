import ctypes
import ctypes.wintypes
import sys
import psutil
import time

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll
user32 = ctypes.windll.user32

PROCESS_ALL_ACCESS = (0x000F0000 | 0x00100000 | 0xFFF)

EXCEPTION_ACCESS_VIOLATION = 0xC0000005

# NtUnmapViewOfSection prototype
ntdll.NtUnmapViewOfSection.restype = ctypes.c_ulong
ntdll.NtUnmapViewOfSection.argtypes = [ctypes.wintypes.HANDLE, ctypes.c_void_p]

# Constants for Windows Messages
WM_CLOSE = 0x0010
WM_QUIT = 0x0012

def get_main_window_handle(pid):
    hwnd_found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
    def enum_windows_proc(hwnd, lParam):
        # Check if window belongs to process
        pid_ = ctypes.wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
        if pid_.value == pid:
            # Check if window is visible and not a child
            if user32.IsWindowVisible(hwnd) and user32.GetParent(hwnd) == 0:
                hwnd_found.append(hwnd)
                return False  # Stop enumeration
        return True

    user32.EnumWindows(enum_windows_proc, 0)
    return hwnd_found[0] if hwnd_found else None

def force_crash_multiple_exceptions(hProcess, count=3):
    raise_exception_addr = kernel32.GetProcAddress(kernel32._handle, b"RaiseException")
    if not raise_exception_addr:
        print("[layer2_method4] Failed to get RaiseException address")
        return False

    CreateRemoteThread = kernel32.CreateRemoteThread
    CreateRemoteThread.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
    CreateRemoteThread.restype = ctypes.c_void_p

    for i in range(count):
        hThread = CreateRemoteThread(hProcess, None, 0, raise_exception_addr, None, 0, None)
        if not hThread:
            print(f"[layer2_method4] Failed to create remote thread for exception #{i+1}")
            return False
        kernel32.WaitForSingleObject(hThread, 3000)
        kernel32.CloseHandle(hThread)
        time.sleep(0.2)
    print(f"[layer2_method4] Injected {count} exceptions successfully.")
    return True

def unmap_process_memory(hProcess):
    # Query the base address of the main module using psutil and read with ctypes
    try:
        import psutil
        proc = psutil.Process(hProcess)
        base_addr = proc.memory_maps()[0].addr.split('-')[0]
        base_addr_int = int(base_addr, 16)
    except Exception as e:
        print("[layer2_method4] Failed to get base address:", e)
        base_addr_int = None

    if base_addr_int is None:
        print("[layer2_method4] Cannot unmap process memory without base address.")
        return False

    status = ntdll.NtUnmapViewOfSection(hProcess, ctypes.c_void_p(base_addr_int))
    if status != 0:
        print(f"[layer2_method4] NtUnmapViewOfSection failed with status 0x{status:x}")
        return False
    print("[layer2_method4] Unmapped main section of process memory successfully.")
    return True

def send_close_messages(hwnd):
    if hwnd:
        print(f"[layer2_method4] Sending WM_CLOSE and WM_QUIT to window {hwnd}.")
        user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
        time.sleep(0.5)
        user32.PostMessageW(hwnd, WM_QUIT, 0, 0)
        time.sleep(0.5)
    else:
        print("[layer2_method4] No main window handle found to send close messages.")

def run(pid):
    try:
        proc = psutil.Process(pid)
    except Exception:
        print(f"[layer2_method4] Process {pid} not found.")
        return False

    hProcess = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not hProcess:
        print(f"[layer2_method4] Failed to open process {pid}")
        return False

    print(f"[layer2_method4] Starting layered attack on PID {pid}...")

    # 1. Send multiple exception injections
    if not force_crash_multiple_exceptions(hProcess, count=5):
        print("[layer2_method4] Exception injection failed.")
    time.sleep(1)

    # 2. Unmap memory sections (try to crash)
    if not unmap_process_memory(hProcess):
        print("[layer2_method4] Memory unmapping failed or skipped.")
    time.sleep(1)

    # 3. Send close messages if GUI app
    hwnd = get_main_window_handle(pid)
    send_close_messages(hwnd)
    time.sleep(2)

    # 4. Check if process still alive, kill forcibly
    if proc.is_running():
        print("[layer2_method4] Process still alive, terminating forcibly.")
        try:
            proc.terminate()
            proc.wait(timeout=3)
            print("[layer2_method4] Process terminated gracefully.")
        except Exception:
            print("[layer2_method4] Graceful termination failed, killing forcibly.")
            try:
                proc.kill()
                proc.wait(timeout=3)
                print("[layer2_method4] Process killed forcibly.")
            except Exception:
                print("[layer2_method4] Failed to kill process.")
                kernel32.CloseHandle(hProcess)
                return False
    else:
        print("[layer2_method4] Process already stopped.")

    kernel32.CloseHandle(hProcess)
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method4.py <pid>")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except:
        print("Invalid PID.")
        sys.exit(1)
    success = run(pid)
    if success:
        print("[layer2_method4] Method finished successfully.")
        sys.exit(0)
    else:
        print("[layer2_method4] Method failed.")
        sys.exit(1)
