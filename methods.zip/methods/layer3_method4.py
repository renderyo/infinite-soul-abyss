import psutil
import os
import sys
import ctypes
import time
import platform
import subprocess

def play_sound(filename):
    filepath = os.path.join(os.path.dirname(__file__), filename)
    system = platform.system()

    if system == "Windows":
        subprocess.run([
            "powershell", "-c", f"(New-Object Media.SoundPlayer '{filepath}').PlaySync();"
        ], check=False)
    elif system == "Darwin":
        subprocess.run(["afplay", filepath], check=False)
    else:
        try:
            subprocess.run(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", filepath],
                check=False
            )
        except FileNotFoundError:
            try:
                subprocess.run(["aplay", filepath], check=False)
            except FileNotFoundError:
                print("[Sound Error] No supported sound player found.")

def terminate_process_winapi(pid):
    PROCESS_TERMINATE = 0x0001
    PROCESS_QUERY_INFORMATION = 0x0400

    handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_INFORMATION, False, pid)
    if not handle:
        return False

    try:
        result = ctypes.windll.kernel32.TerminateProcess(handle, -1)
        ctypes.windll.kernel32.CloseHandle(handle)
        return result != 0
    except Exception:
        ctypes.windll.kernel32.CloseHandle(handle)
        return False

def tamper_process_light(proc):
    # Suspend and resume once quickly (minimal CPU)
    try:
        proc.suspend()
        proc.resume()
    except Exception:
        pass

def degrade_process_light(proc):
    # Lower priority without loops or waits
    try:
        proc.nice(psutil.IDLE_PRIORITY_CLASS)
    except Exception:
        pass

def main():
    if len(sys.argv) < 2:
        print("Usage: python layer3_method3.py <PID>")
        sys.exit(1)

    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID argument")
        sys.exit(1)

    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        print(f"Process {pid} does not exist")
        sys.exit(1)

    print(f"[!!] Layer3_Method3: Initiating beyond OS-level termination on PID {pid} ({proc.name()})")

    # Try normal kill
    try:
        proc.kill()
        time.sleep(0.5)
        if not psutil.pid_exists(pid):
            print("Process terminated successfully by kill()")
            sys.exit(0)
    except Exception:
        pass

    # Try Windows API TerminateProcess if on Windows
    if platform.system() == "Windows":
        print("Trying Windows API TerminateProcess()...")
        if terminate_process_winapi(pid):
            time.sleep(0.5)
            if not psutil.pid_exists(pid):
                print("Process terminated successfully by TerminateProcess()")
                sys.exit(0)
        else:
            print("Windows API termination failed.")

    # Light tampering (suspend/resume once)
    print("Attempting light tampering (suspend/resume)...")
    tamper_process_light(proc)

    # Light degradation (lower priority)
    print("Applying light degradation (lower priority)...")
    degrade_process_light(proc)

    # Final kill attempt after tampering
    try:
        proc.kill()
        time.sleep(0.5)
        if not psutil.pid_exists(pid):
            print("Process terminated successfully after degradation")
            sys.exit(0)
    except Exception:
        pass

    print("Failed to terminate process with Layer3_Method3.")
    play_sound("fail.wav")  # Make sure fail.wav exists
    sys.exit(1)

if __name__ == "__main__":
    main()
