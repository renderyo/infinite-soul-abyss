import sys
import psutil
import os
import signal
import time
import threading
import random

def cpu_stress(duration_sec=3):
    print("[layer1_method6] Starting CPU stress...")
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        for i in range(10000):
            _ = i*i

def affinity_toggler(p, toggle_count=6):
    print("[layer1_method6] Starting CPU affinity toggling...")
    try:
        cpus = list(range(psutil.cpu_count()))
        for _ in range(toggle_count):
            new_affinity = random.sample(cpus, random.randint(1, len(cpus)))
            p.cpu_affinity(new_affinity)
            print(f"[layer1_method6] Set CPU affinity to: {new_affinity}")
            time.sleep(0.5)
    except Exception as e:
        print(f"[layer1_method6] Failed to toggle affinity: {e}")

def file_handle_tamper(p, attempts=5):
    print("[layer1_method6] Starting file handle tampering...")
    try:
        exe_path = p.exe()
        for _ in range(attempts):
            try:
                with open(exe_path, 'rb') as f:
                    f.read(10)
                print("[layer1_method6] Opened and read from executable.")
                time.sleep(0.1)
            except Exception as e:
                print(f"[layer1_method6] File I/O error: {e}")
    except Exception as e:
        print(f"[layer1_method6] Cannot access executable path: {e}")

def layer1_method6(pid):
    print(f"[layer1_method6] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method6] Process found: {p.name()} (PID {pid})")

        # Rapid suspend/resume cycles (very fast)
        try:
            for _ in range(15):
                p.suspend()
                print("[layer1_method6] Process suspended (degradation).")
                time.sleep(0.1)
                p.resume()
                print("[layer1_method6] Process resumed (degradation).")
                time.sleep(0.1)
        except psutil.AccessDenied:
            print("[layer1_method6] Access denied: cannot suspend/resume process.")
        except Exception as e:
            print(f"[layer1_method6] Suspend/resume failed: {e}")

        # Frequent priority toggling (low to high)
        try:
            priorities = []
            if os.name == "nt":
                priorities = [
                    psutil.IDLE_PRIORITY_CLASS,
                    psutil.BELOW_NORMAL_PRIORITY_CLASS,
                    psutil.NORMAL_PRIORITY_CLASS,
                    psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                    psutil.HIGH_PRIORITY_CLASS
                ]
            else:
                priorities = [19, 10, 0, -10, -15]

            for prio in priorities * 2:  # repeat cycle twice
                try:
                    p.nice(prio)
                    print(f"[layer1_method6] Set priority to {prio}.")
                    time.sleep(0.3)
                except Exception as e:
                    print(f"[layer1_method6] Failed to set priority {prio}: {e}")
        except Exception as e:
            print(f"[layer1_method6] Priority toggling failed: {e}")

        # Start CPU stress in a few threads
        stress_threads = []
        for _ in range(3):
            t = threading.Thread(target=cpu_stress, args=(3,))
            t.start()
            stress_threads.append(t)

        # CPU affinity toggling
        affinity_toggler(p)

        # File handle tampering
        file_handle_tamper(p)

        # Wait for CPU stress threads to finish
        for t in stress_threads:
            t.join()

        # Attempt graceful terminate
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method6] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method6] Graceful terminate timed out, forcing kill...")

            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method6] Force kill succeeded.")
                else:
                    print("[layer1_method6] Force kill failed.")
            else:
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method6] Sent SIGKILL.")

            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method6] Process killed successfully.")
                return 0
            else:
                print("[layer1_method6] Process still alive after force kill.")
                return 1

    except psutil.NoSuchProcess:
        print("[layer1_method6] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method6] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method6] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method6] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method6(pid)
    sys.exit(exit_code)
