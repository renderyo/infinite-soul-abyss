import psutil
import os
import sys
import ctypes
import time
import platform
import subprocess
import threading

def play_sound(filename):
    filepath = os.path.join(os.path.dirname(__file__), filename)
    system = platform.system()

    if system == "Windows":
        subprocess.run([
            "powershell", "-c", f"(New-Object Media.SoundPlayer '{filepath}').PlaySync();"
        ], check=False)
    elif system == "Darwin":
        subprocess.run(["afplay", filepath], check=False)
    else:
        try:
            subprocess.run(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", filepath],
                check=False
            )
        except FileNotFoundError:
            try:
                subprocess.run(["aplay", filepath], check=False)
            except FileNotFoundError:
                print("[Sound Error] No supported sound player found.")

# Windows API constants
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_ALL_ACCESS = 0x1F0FFF
THREAD_TERMINATE = 0x0001

kernel32 = ctypes.windll.kernel32

def terminate_process_winapi(pid):
    handle = kernel32.OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_INFORMATION, False, pid)
    if not handle:
        return False
    try:
        result = kernel32.TerminateProcess(handle, -1)
        kernel32.CloseHandle(handle)
        return result != 0
    except Exception:
        kernel32.CloseHandle(handle)
        return False

def close_all_threads(pid):
    # Attempt to open all threads and terminate them forcibly
    # Note: This requires ctypes and is Windows-only
    try:
        import ctypes.wintypes

        THREAD_SUSPEND_RESUME = 0x0002
        THREAD_TERMINATE = 0x0001
        THREAD_QUERY_INFORMATION = 0x0040
        THREAD_ALL_ACCESS = 0x1F03FF

        CreateToolhelp32Snapshot = kernel32.CreateToolhelp32Snapshot
        Thread32First = kernel32.Thread32First
        Thread32Next = kernel32.Thread32Next
        OpenThread = kernel32.OpenThread
        TerminateThread = kernel32.TerminateThread
        CloseHandle = kernel32.CloseHandle

        class THREADENTRY32(ctypes.Structure):
            _fields_ = [
                ('dwSize', ctypes.wintypes.DWORD),
                ('cntUsage', ctypes.wintypes.DWORD),
                ('th32ThreadID', ctypes.wintypes.DWORD),
                ('th32OwnerProcessID', ctypes.wintypes.DWORD),
                ('tpBasePri', ctypes.wintypes.LONG),
                ('tpDeltaPri', ctypes.wintypes.LONG),
                ('dwFlags', ctypes.wintypes.DWORD),
            ]

        thread_entry = THREADENTRY32()
        thread_entry.dwSize = ctypes.sizeof(THREADENTRY32)

        snapshot = CreateToolhelp32Snapshot(0x00000004, 0)  # TH32CS_SNAPTHREAD = 0x00000004

        if snapshot == -1:
            return False

        success = Thread32First(snapshot, ctypes.byref(thread_entry))
        while success:
            if thread_entry.th32OwnerProcessID == pid:
                thread_handle = OpenThread(THREAD_TERMINATE, False, thread_entry.th32ThreadID)
                if thread_handle:
                    TerminateThread(thread_handle, 0)
                    CloseHandle(thread_handle)
            success = Thread32Next(snapshot, ctypes.byref(thread_entry))
        kernel32.CloseHandle(snapshot)
        return True
    except Exception:
        return False

def brother_termination(pid):
    """
    The Brother Termination: aggressively terminate process and threads,
    reopen with max privileges, and try TerminateProcess multiple times.
    """
    # Open process handle with all access
    hProcess = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not hProcess:
        return False

    try:
        # Terminate all threads forcibly
        close_all_threads(pid)

        # Attempt to terminate process multiple times
        for _ in range(3):
            if kernel32.TerminateProcess(hProcess, -1):
                time.sleep(0.2)
                if not psutil.pid_exists(pid):
                    return True
            time.sleep(0.3)

    finally:
        kernel32.CloseHandle(hProcess)

    return False

def degrade_process_light(proc):
    try:
        proc.nice(psutil.IDLE_PRIORITY_CLASS)
    except Exception:
        pass

def tamper_process_light(proc):
    try:
        proc.suspend()
        time.sleep(0.1)
        proc.resume()
    except Exception:
        pass

def main():
    if len(sys.argv) < 2:
        print("Usage: python layer3_method4.py <PID>")
        sys.exit(1)

    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID argument")
        sys.exit(1)

    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        print(f"Process {pid} does not exist")
        sys.exit(1)

    print(f"[!!] Layer3_Method4: Initiating VERY AGGRESSIVE termination on PID {pid} ({proc.name()})")

    # Normal kill first
    try:
        proc.kill()
        time.sleep(0.5)
        if not psutil.pid_exists(pid):
            print("Process terminated by kill()")
            sys.exit(0)
    except Exception:
        pass

    # Windows API TerminateProcess
    if platform.system() == "Windows":
        print("Trying Windows API TerminateProcess()...")
        if terminate_process_winapi(pid):
            time.sleep(0.5)
            if not psutil.pid_exists(pid):
                print("Process terminated by TerminateProcess()")
                sys.exit(0)
            else:
                print("Process still alive after TerminateProcess()")

        print("Executing Brother Termination...")
        if brother_termination(pid):
            print("Process terminated by Brother Termination")
            sys.exit(0)
        else:
            print("Brother Termination failed")

    else:
        # Unix: try SIGKILL
        try:
            os.kill(pid, 9)
            time.sleep(0.5)
            if not psutil.pid_exists(pid):
                print("Process terminated by SIGKILL")
                sys.exit(0)
        except Exception:
            print("SIGKILL failed")

    # Tampering and degradation fallback
    print("Applying light tampering and degradation...")
    tamper_process_light(proc)
    degrade_process_light(proc)

    # Final kill attempt
    try:
        proc.kill()
        time.sleep(0.5)
        if not psutil.pid_exists(pid):
            print("Process terminated after tampering/degradation")
            sys.exit(0)
    except Exception:
        pass

    print("Failed to terminate process with Layer3_Method4.")
    play_sound("lol.wav")
    sys.exit(1)

if __name__ == "__main__":
    main()
