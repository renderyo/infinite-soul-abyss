import ctypes
import sys
import psutil
import random
import time
from ctypes import wintypes

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll
user32 = ctypes.windll.user32

PROCESS_ALL_ACCESS = 0x001F0FFF
THREAD_SUSPEND_RESUME = 0x0002

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

OpenThread = kernel32.OpenThread
OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenThread.restype = wintypes.HANDLE

SuspendThread = kernel32.SuspendThread
SuspendThread.argtypes = [wintypes.HANDLE]
SuspendThread.restype = wintypes.DWORD

ResumeThread = kernel32.ResumeThread
ResumeThread.argtypes = [wintypes.HANDLE]
ResumeThread.restype = wintypes.DWORD

TerminateThread = kernel32.TerminateThread
TerminateThread.argtypes = [wintypes.HANDLE, wintypes.DWORD]
TerminateThread.restype = wintypes.BOOL

SetPriorityClass = kernel32.SetPriorityClass
SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetPriorityClass.restype = wintypes.BOOL

SetProcessAffinityMask = kernel32.SetProcessAffinityMask
SetProcessAffinityMask.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetProcessAffinityMask.restype = wintypes.BOOL

VirtualAllocEx = kernel32.VirtualAllocEx
VirtualAllocEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
VirtualAllocEx.restype = wintypes.LPVOID

WriteProcessMemory = kernel32.WriteProcessMemory
WriteProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.LPCVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
WriteProcessMemory.restype = wintypes.BOOL

NtTerminateProcess = ntdll.NtTerminateProcess
NtTerminateProcess.argtypes = [wintypes.HANDLE, wintypes.ULONG]
NtTerminateProcess.restype = wintypes.ULONG

EnumWindows = user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
GetWindowThreadProcessId = user32.GetWindowThreadProcessId
SetWindowTextW = user32.SetWindowTextW
PostMessageW = user32.PostMessageW
WM_CLOSE = 0x0010

MEM_COMMIT = 0x1000
PAGE_EXECUTE_READWRITE = 0x40

def open_process(pid):
    handle = OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not handle:
        print(f"[layer2_method7] Failed to open process PID {pid}")
    return handle

def aggressive_thread_glitch(pid):
    print("[layer2_method7] Aggressively suspending/resuming threads")
    try:
        proc = psutil.Process(pid)
        threads = proc.threads()
        for _ in range(5):  # repeat entire cycle 5 times
            random.shuffle(threads)
            for thread in threads:
                tid = thread.id
                th = OpenThread(THREAD_SUSPEND_RESUME, False, tid)
                if th:
                    loops = random.randint(5, 10)
                    for _ in range(loops):
                        SuspendThread(th)
                        time.sleep(0.005)
                        ResumeThread(th)
                        time.sleep(0.005)
                    CloseHandle(th)
        print("[layer2_method7] Thread glitch complete")
    except Exception as e:
        print(f"[layer2_method7] Error during thread glitch: {e}")

def priority_affinity_chaos(handle):
    print("[layer2_method7] Cycling priority and affinity rapidly")
    priorities = [0x00000040, 0x00000100, 0x00000080, 0x00000020]  # BELOW_NORMAL, ABOVE_NORMAL, IDLE, NORMAL
    affinities = [0x1, 0x2, 0x4, 0x8, 0xF]
    for _ in range(20):  # More cycles for chaos
        prio = random.choice(priorities)
        aff = random.choice(affinities)
        if SetPriorityClass(handle, prio):
            print(f"[layer2_method7] Set priority: {hex(prio)}")
        if SetProcessAffinityMask(handle, aff):
            print(f"[layer2_method7] Set affinity mask: {bin(aff)}")
        time.sleep(0.05)

def rename_windows_glitch(pid):
    glitch_titles = [
        "崩溃", "Glitch∞Storm", "ERROR_404", "PROCESS_CORRUPT", 
        "⚠️系统故障⚠️", "???????", "∞∞∞∞∞∞∞", "█▓▒░☠☢☣☤▒▓█",
        "𝔾𝕃𝕀𝕋ℂℍ𝔼𝔻", "⨂⨂⨂⨂⨂⨂", "♛♛♛♛♛♛"
    ]
    found = []

    def enum_callback(hwnd, lParam):
        pid_ = wintypes.DWORD()
        GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
        if pid_.value == pid:
            title = random.choice(glitch_titles)
            SetWindowTextW(hwnd, title)
            found.append(hwnd)
        return True

    EnumWindows(EnumWindowsProc(enum_callback), 0)
    print(f"[layer2_method7] Glitched {len(found)} window titles")

def inject_garbage_memory(handle):
    print("[layer2_method7] Injecting garbage into process memory")
    size = 4096
    garbage = bytes(random.getrandbits(8) for _ in range(size))
    addr = VirtualAllocEx(handle, None, size, MEM_COMMIT, PAGE_EXECUTE_READWRITE)
    if not addr:
        print("[layer2_method7] Memory allocation failed")
        return
    written = ctypes.c_size_t()
    if WriteProcessMemory(handle, addr, garbage, size, ctypes.byref(written)):
        print(f"[layer2_method7] Wrote {written.value} bytes of garbage")
    else:
        print("[layer2_method7] Failed to write garbage memory")

def spam_debug_events(pid):
    print("[layer2_method7] Simulating debug attach/detach events")

    # NOTE: True debug event injection is complex; here we just simulate delay/chaos
    for _ in range(10):
        time.sleep(0.05)
        # Real debug event injection would require Windows Debug APIs
        # which are outside scope here.

def terminate_all_threads(pid):
    print("[layer2_method7] Terminating all threads forcibly")
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            tid = thread.id
            th = OpenThread(THREAD_SUSPEND_RESUME, False, tid)
            if th:
                kernel32.TerminateThread(th, 0)
                CloseHandle(th)
        print("[layer2_method7] All threads terminated")
    except Exception as e:
        print(f"[layer2_method7] Failed to terminate threads: {e}")

def force_nt_terminate_process(handle):
    print("[layer2_method7] Calling NtTerminateProcess to kill process")
    status = NtTerminateProcess(handle, 0)
    if status == 0:
        print("[layer2_method7] Process terminated successfully via NtTerminateProcess")
        return True
    else:
        print(f"[layer2_method7] NtTerminateProcess failed with status 0x{status:X}")
        return False

def run(pid):
    handle = open_process(pid)
    if not handle:
        return False

    aggressive_thread_glitch(pid)
    priority_affinity_chaos(handle)
    rename_windows_glitch(pid)
    inject_garbage_memory(handle)
    spam_debug_events(pid)
    terminate_all_threads(pid)

    time.sleep(1)

    result = force_nt_terminate_process(handle)
    kernel32.CloseHandle(handle)

    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method7.py <pid>")
        sys.exit(1)

    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID")
        sys.exit(1)

    success = run(pid)
    sys.exit(0 if success else 1)
