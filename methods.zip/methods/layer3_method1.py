import os
import sys
import ctypes
import psutil
import subprocess
import time
import logging
import winsound
import win32com.client  # Requires: pip install pywin32

# Configuration
PROCESS_NAME = "stubborn_process.exe"  # Change to target process name
AUDIO_FILE = "finals.wav"  # Must be in same folder
LOG_FILE = "layer2_method10.log"

# Setup logging
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format='[%(asctime)s] %(message)s')

# Privilege escalation check
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

# Method 1: psutil
def kill_psutil(proc_name):
    logging.info("[Method 1] Attempting psutil kill")
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == proc_name:
            logging.info(f"Found PID {proc.pid} with name {proc_name}")
            try:
                proc.kill()
                logging.info("psutil kill successful")
                return True
            except Exception as e:
                logging.warning(f"psutil failed: {e}")
    return False

# Method 2: taskkill
def kill_taskkill(proc_name):
    logging.info("[Method 2] Attempting taskkill")
    try:
        subprocess.run(["taskkill", "/F", "/IM", proc_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logging.info("taskkill command sent")
        return True
    except Exception as e:
        logging.warning(f"taskkill failed: {e}")
    return False

# Method 3: WMI
def kill_wmi(proc_name):
    logging.info("[Method 3] Attempting WMI termination")
    try:
        wmi = win32com.client.GetObject("winmgmts:")
        for p in wmi.InstancesOf("Win32_Process"):
            if p.Name == proc_name:
                p.Terminate()
                logging.info("WMI termination successful")
                return True
    except Exception as e:
        logging.warning(f"WMI termination failed: {e}")
    return False

# Method 4: Windows API
def kill_winapi(proc_name):
    logging.info("[Method 4] Attempting TerminateProcess via Windows API")
    PROCESS_TERMINATE = 1
    try:
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'] == proc_name:
                handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, proc.pid)
                if handle:
                    result = ctypes.windll.kernel32.TerminateProcess(handle, -1)
                    ctypes.windll.kernel32.CloseHandle(handle)
                    if result:
                        logging.info("TerminateProcess succeeded")
                        return True
    except Exception as e:
        logging.warning(f"WinAPI termination failed: {e}")
    return False

# Audio (symbolic)
def play_death_sound():
    try:
        winsound.PlaySound(AUDIO_FILE, winsound.SND_FILENAME | winsound.SND_ASYNC)
        logging.info(f"Playing {AUDIO_FILE}")
    except Exception as e:
        logging.warning(f"Failed to play sound: {e}")

# Execute all layers
def execute_termination():
    if not is_admin():
        logging.warning("You must run this script as administrator!")
        print("Run as admin.")
        return

    logging.info("=== LAYER 2 METHOD 10 INITIATED ===")
    play_death_sound()
    time.sleep(1)

    if kill_psutil(PROCESS_NAME): return
    if kill_taskkill(PROCESS_NAME): return
    if kill_wmi(PROCESS_NAME): return
    if kill_winapi(PROCESS_NAME): return

    logging.error("All methods failed. Process may be protected or system-level.")
    print("Could not terminate the process.")

if __name__ == "__main__":
    execute_termination()
