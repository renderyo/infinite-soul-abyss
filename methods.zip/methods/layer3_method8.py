import ctypes
import os
import psutil
import time
import win32api
import win32con
import win32process
import win32security
import win32event

def has_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def strong_terminate(pid):
    if pid in (0, 4, os.getpid()):
        return  # Avoid PID 0 (Idle), 4 (System), and this script itself

    try:
        proc = psutil.Process(pid)
        proc.suspend()
        proc.nice(psutil.REALTIME_PRIORITY_CLASS)
    except Exception:
        pass

    try:
        handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, pid)
        if handle:
            ctypes.windll.kernel32.TerminateProcess(handle, -1)
            ctypes.windll.kernel32.CloseHandle(handle)
            return
    except Exception:
        pass

    try:
        os.system(f"taskkill /PID {pid} /F >nul 2>&1")
    except:
        pass

    try:
        proc = psutil.Process(pid)
        proc.kill()
    except:
        pass

    try:
        # Use WMI to try process termination
        import wmi
        f = wmi.WMI()
        for p in f.Win32_Process(ProcessId=pid):
            p.Terminate()
    except:
        pass

    try:
        # Memory overwrite fallback
        handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, pid)
        if handle:
            mem = ctypes.create_string_buffer(b"\x00" * 512)
            ctypes.windll.kernel32.WriteProcessMemory(handle, 0x00000000, mem, len(mem), None)
            ctypes.windll.kernel32.CloseHandle(handle)
    except:
        pass

def terminate_all_except_self():
    current_pid = os.getpid()
    for proc in psutil.process_iter(['pid', 'name']):
        pid = proc.info['pid']
        try:
            strong_terminate(pid)
        except:
            pass

if __name__ == "__main__":
    if not has_admin():
        ctypes.windll.shell32.ShellExecuteW(None, "runas", __file__, None, None, 1)
    else:
        terminate_all_except_self()
