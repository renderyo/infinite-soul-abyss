import ctypes
import sys
import psutil
import time
import subprocess
import random
import string
from ctypes import wintypes

kernel32 = ctypes.windll.kernel32
ntdll = ctypes.windll.ntdll
user32 = ctypes.windll.user32

PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010
PROCESS_SUSPEND_RESUME = 0x0800

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

TerminateProcess = kernel32.TerminateProcess
TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
TerminateProcess.restype = wintypes.BOOL

CloseHandle = kernel32.CloseHandle

NtSuspendProcess = ntdll.NtSuspendProcess
NtSuspendProcess.argtypes = [wintypes.HANDLE]
NtSuspendProcess.restype = wintypes.DWORD

NtResumeProcess = ntdll.NtResumeProcess
NtResumeProcess.argtypes = [wintypes.HANDLE]
NtResumeProcess.restype = wintypes.DWORD

CreateRemoteThread = kernel32.CreateRemoteThread
CreateRemoteThread.argtypes = [
    wintypes.HANDLE,
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.c_void_p,
    ctypes.c_void_p,
    wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD)
]
CreateRemoteThread.restype = wintypes.HANDLE

def open_process(pid):
    handle = OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_INFORMATION | PROCESS_VM_READ | PROCESS_SUSPEND_RESUME, False, pid)
    if not handle:
        print(f"[layer2_method8] Failed to open process PID {pid}")
    return handle

def task_manager_end_task(pid):
    print("[layer2_method8] Trying Task Manager style End Task (taskkill.exe)")
    try:
        completed = subprocess.run(
            ["taskkill", "/PID", str(pid), "/F"],
            capture_output=True, text=True, timeout=5
        )
        print(f"[layer2_method8] taskkill output:\n{completed.stdout.strip()}")
        return completed.returncode == 0
    except Exception as e:
        print(f"[layer2_method8] taskkill.exe failed: {e}")
        return False

def fallback_terminate_process(handle):
    print("[layer2_method8] Falling back to TerminateProcess API")
    result = TerminateProcess(handle, 1)
    if result:
        print("[layer2_method8] Process terminated via TerminateProcess")
    else:
        print("[layer2_method8] TerminateProcess call failed")
    return result

def suspend_resume_process(handle):
    print("[layer2_method8] Suspending process via NtSuspendProcess")
    status = NtSuspendProcess(handle)
    if status != 0:
        print(f"[layer2_method8] NtSuspendProcess failed with status: {status}")
        return False
    time.sleep(0.5)
    print("[layer2_method8] Resuming process via NtResumeProcess")
    status = NtResumeProcess(handle)
    if status != 0:
        print(f"[layer2_method8] NtResumeProcess failed with status: {status}")
        return False
    return True

def inject_crash_thread(handle):
    """
    Inject a remote thread that calls ExitProcess(1).
    """
    print("[layer2_method8] Injecting remote thread to force crash")
    ExitProcess = kernel32.GetProcAddress(kernel32._handle, b"ExitProcess")
    if not ExitProcess:
        print("[layer2_method8] Could not get ExitProcess address")
        return False
    thread_id = wintypes.DWORD()
    thread_handle = CreateRemoteThread(handle, None, 0, ExitProcess, None, 0, ctypes.byref(thread_id))
    if not thread_handle:
        print("[layer2_method8] Failed to create remote thread")
        return False
    kernel32.CloseHandle(thread_handle)
    print("[layer2_method8] Remote thread injected successfully")
    return True

def minimal_tampering(pid):
    try:
        proc = psutil.Process(pid)
        print("[layer2_method8] Tampering: Repeatedly changing priority and window title")

        original_priority = proc.nice()
        priorities = [psutil.IDLE_PRIORITY_CLASS, psutil.BELOW_NORMAL_PRIORITY_CLASS, psutil.NORMAL_PRIORITY_CLASS]
        titles = ["Glitched Process", "Infected by ISA", "Tampered!"]
        
        for _ in range(3):
            p = random.choice(priorities)
            proc.nice(p)
            try:
                # Change window title of main window if possible (best effort)
                hwnds = []
                def enum_windows(hwnd, lParam):
                    pid_ = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
                    if pid_.value == pid:
                        hwnds.append(hwnd)
                    return True
                EnumWindowsProto = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
                user32.EnumWindows(EnumWindowsProto(enum_windows), 0)

                for hwnd in hwnds:
                    title = random.choice(titles)
                    user32.SetWindowTextW(hwnd, title)
            except Exception:
                pass

            time.sleep(0.15)
        
        proc.nice(original_priority)
    except Exception as e:
        print(f"[layer2_method8] Tampering failed: {e}")

def run(pid):
    handle = open_process(pid)
    if not handle:
        return False

    # Try Task Manager End Task first
    if task_manager_end_task(pid):
        print("[layer2_method8] End Task succeeded.")
        CloseHandle(handle)
        return True

    # Suspend + Resume trick to confuse process (not heavy on CPU)
    suspend_resume_process(handle)

    minimal_tampering(pid)

    time.sleep(0.5)  # small wait

    if not psutil.pid_exists(pid):
        print("[layer2_method8] Process terminated after tampering.")
        CloseHandle(handle)
        return True

    # Inject remote thread crash
    if inject_crash_thread(handle):
        time.sleep(0.5)
        if not psutil.pid_exists(pid):
            print("[layer2_method8] Process terminated after remote thread injection.")
            CloseHandle(handle)
            return True

    # Final fallback to TerminateProcess
    if fallback_terminate_process(handle):
        CloseHandle(handle)
        return True

    CloseHandle(handle)
    return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method8.py <pid>")
        sys.exit(1)

    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID")
        sys.exit(1)

    success = run(pid)
    sys.exit(0 if success else 1)
