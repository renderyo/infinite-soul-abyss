import sys
import psutil
import os
import signal
import time

def layer1_method2(pid):
    print(f"[layer1_method2] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method2] Process found: {p.name()} (PID {pid})")

        # Try suspending the process to freeze it (Windows/Linux only)
        try:
            p.suspend()
            print("[layer1_method2] Process suspended.")
            time.sleep(1)  # give it a moment suspended
        except psutil.AccessDenied:
            print("[layer1_method2] Access denied: cannot suspend process.")
        except Exception as e:
            print(f"[layer1_method2] Failed to suspend process: {e}")

        # Then try to terminate gracefully
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method2] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method2] Graceful terminate timed out, forcing kill...")

            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method2] Force kill succeeded.")
                else:
                    print("[layer1_method2] Force kill failed.")
            else:
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method2] Sent SIGKILL.")

            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method2] Process killed successfully.")
                return 0
            else:
                print("[layer1_method2] Process still alive after force kill.")
                return 1
    except psutil.NoSuchProcess:
        print("[layer1_method2] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method2] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method2] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method2] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method2(pid)
    sys.exit(exit_code)
