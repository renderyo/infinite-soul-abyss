import sys
import psutil
import os
import signal
import time

def layer1_method3(pid):
    print(f"[layer1_method3] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method3] Process found: {p.name()} (PID {pid})")

        # Tampering: suspend and resume process multiple times to destabilize it
        try:
            for _ in range(3):
                p.suspend()
                print("[layer1_method3] Process suspended (tampering).")
                time.sleep(0.5)
                p.resume()
                print("[layer1_method3] Process resumed (tampering).")
                time.sleep(0.5)
        except psutil.AccessDenied:
            print("[layer1_method3] Access denied: cannot suspend/resume process.")
        except Exception as e:
            print(f"[layer1_method3] Tampering failed: {e}")

        # Try to terminate gracefully
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method3] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method3] Graceful terminate timed out, forcing kill...")

            # Additional slight tampering: adjust process priority before killing
            try:
                if os.name == "nt":
                    p.nice(psutil.REALTIME_PRIORITY_CLASS)
                    print("[layer1_method3] Process priority set to REALTIME (Windows).")
                else:
                    p.nice(-20)  # Highest priority on Unix
                    print("[layer1_method3] Process priority set to highest (Unix).")
            except Exception as e:
                print(f"[layer1_method3] Failed to set priority: {e}")

            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method3] Force kill succeeded.")
                else:
                    print("[layer1_method3] Force kill failed.")
            else:
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method3] Sent SIGKILL.")

            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method3] Process killed successfully.")
                return 0
            else:
                print("[layer1_method3] Process still alive after force kill.")
                return 1

    except psutil.NoSuchProcess:
        print("[layer1_method3] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method3] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method3] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method3] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method3(pid)
    sys.exit(exit_code)
