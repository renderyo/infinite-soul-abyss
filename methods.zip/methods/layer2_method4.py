import ctypes
import sys
import psutil
import time

kernel32 = ctypes.windll.kernel32

PROCESS_ALL_ACCESS = (0x000F0000 | 0x00100000 | 0xFFF)

# Exception code for access violation
EXCEPTION_ACCESS_VIOLATION = 0xC0000005

def force_crash_process(pid):
    # Open process
    hProcess = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not hProcess:
        print(f"[layer2_method3] Failed to open process {pid}")
        return False

    # Prototype for RaiseException
    # VOID WINAPI RaiseException(
    #   DWORD dwExceptionCode,
    #   DWORD dwExceptionFlags,
    #   DWORD nNumberOfArguments,
    #   CONST ULONG_PTR *lpArguments
    # );
    raise_exception_addr = kernel32.GetProcAddress(kernel32._handle, b"RaiseException")
    if not raise_exception_addr:
        print("[layer2_method3] Failed to get address of RaiseException")
        kernel32.CloseHandle(hProcess)
        return False

    # CreateRemoteThread arguments
    # DWORD WINAPI CreateRemoteThread(
    #   HANDLE hProcess,
    #   LPSECURITY_ATTRIBUTES lpThreadAttributes,
    #   SIZE_T dwStackSize,
    #   LPTHREAD_START_ROUTINE lpStartAddress,
    #   LPVOID lpParameter,
    #   DWORD dwCreationFlags,
    #   LPDWORD lpThreadId
    # );
    CreateRemoteThread = kernel32.CreateRemoteThread
    CreateRemoteThread.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
    CreateRemoteThread.restype = ctypes.c_void_p

    # We want to call RaiseException with:
    # dwExceptionCode = EXCEPTION_ACCESS_VIOLATION
    # dwExceptionFlags = 0
    # nNumberOfArguments = 0
    # lpArguments = NULL

    # Prepare a small function wrapper in remote thread
    # Actually, we can try to call RaiseException directly with NULL params as lpParameter

    thread_id = ctypes.c_ulong(0)
    hThread = CreateRemoteThread(
        hProcess,
        None,
        0,
        raise_exception_addr,
        None,
        0,
        ctypes.byref(thread_id)
    )

    if not hThread:
        print(f"[layer2_method3] Failed to create remote thread in process {pid}")
        kernel32.CloseHandle(hProcess)
        return False

    # Wait for thread to finish
    kernel32.WaitForSingleObject(hThread, 5000)
    kernel32.CloseHandle(hThread)
    kernel32.CloseHandle(hProcess)
    print(f"[layer2_method3] Remote exception injected into process {pid} - should crash.")
    return True

def run(pid):
    try:
        proc = psutil.Process(pid)
    except Exception:
        print(f"[layer2_method3] Process {pid} not found.")
        return False

    print(f"[layer2_method3] Injecting crash into PID {pid}...")

    success = force_crash_process(pid)

    time.sleep(0.5)

    if success:
        # Give some time to crash
        time.sleep(1)
        if proc.is_running():
            print("[layer2_method3] Process still running, attempting kill.")
            try:
                proc.kill()
                proc.wait(timeout=1)
                print("[layer2_method3] Process killed successfully.")
                return True
            except Exception:
                print("[layer2_method3] Failed to kill process.")
                return False
        else:
            print("[layer2_method3] Process crashed successfully.")
            return True
    else:
        print("[layer2_method3] Crash injection failed.")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method3.py <pid>")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except Exception:
        print("Invalid PID")
        sys.exit(1)
    run(pid)
