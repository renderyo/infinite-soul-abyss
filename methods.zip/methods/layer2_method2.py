import psutil
import ctypes
import os
import sys
import threading
import time

def layer2_method2(pid):
    try:
        proc = psutil.Process(pid)
        system = os.name

        if system == "nt":
            kernel32 = ctypes.windll.kernel32
            THREAD_SUSPEND_RESUME = 0x0002
            THREAD_QUERY_INFORMATION = 0x0040
            THREAD_SET_INFORMATION = 0x0020

            # Debugger attach/detach to confuse process internals
            def debug_trick():
                DebugActiveProcess = kernel32.DebugActiveProcess
                DebugActiveProcess.argtypes = [ctypes.c_ulong]
                DebugActiveProcess.restype = ctypes.c_bool

                DebugActiveProcessStop = kernel32.DebugActiveProcessStop
                DebugActiveProcessStop.argtypes = [ctypes.c_ulong]
                DebugActiveProcessStop.restype = ctypes.c_bool

                if DebugActiveProcess(pid):
                    time.sleep(3)  # Keep process in debug mode briefly
                    DebugActiveProcessStop(pid)

            # Aggressive thread suspend/resume loop
            def thread_glitch():
                for _ in range(40):
                    try:
                        for t in proc.threads():
                            h = kernel32.OpenThread(THREAD_SUSPEND_RESUME | THREAD_QUERY_INFORMATION | THREAD_SET_INFORMATION, False, t.id)
                            if h:
                                kernel32.SuspendThread(h)
                                time.sleep(0.01)
                                kernel32.ResumeThread(h)
                                kernel32.CloseHandle(h)
                    except Exception:
                        pass

            # Environment variable glitch (illusion)
            def env_glitch():
                try:
                    env = proc.environ()
                    if env:
                        env["INFINITE_SOUL_ABYSS"] = "GLITCHED"
                except Exception:
                    pass

            # File rename and lock trick
            def file_lock_trick():
                try:
                    exe_path = proc.exe()
                    corrupted_path = exe_path + ".corrupt"
                    if os.path.exists(exe_path) and not os.path.exists(corrupted_path):
                        os.rename(exe_path, corrupted_path)
                        with open(exe_path, "w") as f:
                            f.write("This file has been glitched by Infinite Soul Abyss.")
                        locked_file = open(exe_path, "r+")
                        time.sleep(5)
                        locked_file.close()
                        os.rename(corrupted_path, exe_path)
                except Exception:
                    pass

            # Light memory info querying to stress process a little
            def mem_query_stress():
                try:
                    for _ in range(100):
                        _ = proc.memory_info()
                        _ = proc.memory_maps()
                        time.sleep(0.01)
                except Exception:
                    pass

            # Run glitch tasks concurrently
            threads = [
                threading.Thread(target=debug_trick),
                threading.Thread(target=thread_glitch),
                threading.Thread(target=env_glitch),
                threading.Thread(target=file_lock_trick),
                threading.Thread(target=mem_query_stress),
            ]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=10)

        else:
            # POSIX fallback: suspend/resume threads + env glitch + mem query
            def posix_thread_glitch():
                for _ in range(40):
                    try:
                        for t in proc.threads():
                            os.kill(t.id, 19)  # SIGSTOP
                        time.sleep(0.01)
                        for t in proc.threads():
                            os.kill(t.id, 18)  # SIGCONT
                        time.sleep(0.01)
                    except Exception:
                        pass

            def env_glitch():
                try:
                    env = proc.environ()
                    if env:
                        env["INFINITE_SOUL_ABYSS"] = "GLITCHED"
                except Exception:
                    pass

            def mem_query_stress():
                try:
                    for _ in range(100):
                        _ = proc.memory_info()
                        _ = proc.memory_maps()
                        time.sleep(0.01)
                except Exception:
                    pass

            threads = [
                threading.Thread(target=posix_thread_glitch),
                threading.Thread(target=env_glitch),
                threading.Thread(target=mem_query_stress),
            ]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=10)

        # Final terminate/kill with retries
        backoff = 0.2
        for _ in range(6):
            try:
                proc.terminate()
                proc.wait(timeout=backoff)
                return True
            except Exception:
                try:
                    proc.kill()
                    proc.wait(timeout=backoff)
                    return True
                except Exception:
                    time.sleep(backoff)
                    backoff *= 2

        return False

    except Exception as e:
        print(f"[layer2_method2] Failed: {e}")
        return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer2_method2] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer2_method2] Invalid PID argument.")
        sys.exit(1)
    layer2_method2(pid)
