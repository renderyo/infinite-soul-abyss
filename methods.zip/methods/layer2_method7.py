import ctypes
import sys
import psutil
import random
import time
from ctypes import wintypes

kernel32 = ctypes.windll.kernel32
user32 = ctypes.windll.user32

PROCESS_ALL_ACCESS = 0x001F0FFF
THREAD_SUSPEND_RESUME = 0x0002

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

OpenThread = kernel32.OpenThread
OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenThread.restype = wintypes.HANDLE

SuspendThread = kernel32.SuspendThread
SuspendThread.argtypes = [wintypes.HANDLE]
SuspendThread.restype = wintypes.DWORD

ResumeThread = kernel32.ResumeThread
ResumeThread.argtypes = [wintypes.HANDLE]
ResumeThread.restype = wintypes.DWORD

SetPriorityClass = kernel32.SetPriorityClass
SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetPriorityClass.restype = wintypes.BOOL

SetProcessAffinityMask = kernel32.SetProcessAffinityMask
SetProcessAffinityMask.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetProcessAffinityMask.restype = wintypes.BOOL

EnumWindows = user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
GetWindowThreadProcessId = user32.GetWindowThreadProcessId
SetWindowTextW = user32.SetWindowTextW
PostMessageW = user32.PostMessageW
WM_CLOSE = 0x0010

def open_process(pid):
    handle = OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not handle:
        print(f"[layer2_method6] Failed to open process PID {pid}")
    return handle

def glitch_threads(pid):
    try:
        proc = psutil.Process(pid)
        for thread in proc.threads():
            tid = thread.id
            th = OpenThread(THREAD_SUSPEND_RESUME, False, tid)
            if th:
                # Suspend and resume threads in random loops to confuse process
                for _ in range(random.randint(3, 7)):
                    SuspendThread(th)
                    time.sleep(0.01 * random.randint(1, 5))
                    ResumeThread(th)
                    time.sleep(0.01 * random.randint(1, 5))
                kernel32.CloseHandle(th)
        print("[layer2_method6] Threads glitch completed")
    except Exception as e:
        print(f"[layer2_method6] Error glitching threads: {e}")

def glitch_priority_and_affinity(handle):
    # Cycle through random priorities and affinities several times
    priorities = [0x00000040, 0x00000100, 0x00000080]  # BELOW_NORMAL, ABOVE_NORMAL, IDLE
    affinities = [0x1, 0x2, 0x4, 0x8, 0xF]  # CPUs 0-3 or all 4
    for _ in range(5):
        prio = random.choice(priorities)
        aff = random.choice(affinities)
        if SetPriorityClass(handle, prio):
            print(f"[layer2_method6] Set priority: {hex(prio)}")
        else:
            print("[layer2_method6] Failed to set priority")
        if SetProcessAffinityMask(handle, aff):
            print(f"[layer2_method6] Set affinity mask: {bin(aff)}")
        else:
            print("[layer2_method6] Failed to set affinity")
        time.sleep(0.1)

def rename_windows_randomly(pid):
    titles = ["崩溃", "Glitch∞Storm", "ERROR_404", "PROCESS_CORRUPT", "⚠️系统故障⚠️", "???????", "∞∞∞∞∞∞∞"]
    found = []

    def enum_callback(hwnd, lParam):
        pid_ = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
        if pid_.value == pid:
            title = random.choice(titles)
            SetWindowTextW(hwnd, title)
            found.append(hwnd)
        return True

    EnumWindows(EnumWindowsProc(enum_callback), 0)
    print(f"[layer2_method6] Renamed {len(found)} windows to glitch titles")

def send_close_messages(pid):
    hwnds = []

    def enum_callback(hwnd, lParam):
        pid_ = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_))
        if pid_.value == pid:
            hwnds.append(hwnd)
        return True

    EnumWindows(EnumWindowsProc(enum_callback), 0)
    for hwnd in hwnds:
        PostMessageW(hwnd, WM_CLOSE, 0, 0)
    print(f"[layer2_method6] Sent WM_CLOSE to {len(hwnds)} windows")

def run(pid):
    handle = open_process(pid)
    if not handle:
        return False

    glitch_threads(pid)
    glitch_priority_and_affinity(handle)
    rename_windows_randomly(pid)
    send_close_messages(pid)

    kernel32.CloseHandle(handle)
    print("[layer2_method6] Glitch attack done. Waiting 2 seconds for process to self-terminate...")
    time.sleep(2)

    # Check if process still running, if yes, fail gracefully
    try:
        proc = psutil.Process(pid)
        if proc.is_running():
            print("[layer2_method6] Process still alive after glitching.")
            return False
    except psutil.NoSuchProcess:
        print("[layer2_method6] Process terminated successfully.")
        return True

    return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method6.py <pid>")
        sys.exit(1)

    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID.")
        sys.exit(1)

    success = run(pid)
    sys.exit(0 if success else 1)
