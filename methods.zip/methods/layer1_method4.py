import sys
import psutil
import os
import signal
import time

def layer1_method4(pid):
    print(f"[layer1_method4] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method4] Process found: {p.name()} (PID {pid})")

        # Stronger tampering: suspend/resume multiple times quickly
        try:
            for _ in range(5):
                p.suspend()
                print("[layer1_method4] Process suspended (tampering).")
                time.sleep(0.3)
                p.resume()
                print("[layer1_method4] Process resumed (tampering).")
                time.sleep(0.3)
        except psutil.AccessDenied:
            print("[layer1_method4] Access denied: cannot suspend/resume process.")
        except Exception as e:
            print(f"[layer1_method4] Tampering suspend/resume failed: {e}")

        # Tampering: rapidly change priority multiple times
        try:
            for priority in [psutil.IDLE_PRIORITY_CLASS, psutil.HIGH_PRIORITY_CLASS, psutil.NORMAL_PRIORITY_CLASS]:
                try:
                    if os.name == "nt":
                        p.nice(priority)
                        print(f"[layer1_method4] Set Windows priority to {priority}.")
                    else:
                        # On Unix, priority is -20 to 19, lower is higher priority
                        nice_val = {psutil.IDLE_PRIORITY_CLASS: 19,
                                    psutil.HIGH_PRIORITY_CLASS: -10,
                                    psutil.NORMAL_PRIORITY_CLASS: 0}.get(priority, 0)
                        p.nice(nice_val)
                        print(f"[layer1_method4] Set Unix nice to {nice_val}.")
                    time.sleep(0.4)
                except Exception as e:
                    print(f"[layer1_method4] Failed to set priority {priority}: {e}")
        except Exception as e:
            print(f"[layer1_method4] Priority tampering failed: {e}")

        # Attempt graceful terminate
        p.terminate()
        try:
            p.wait(timeout=3)
            print("[layer1_method4] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method4] Graceful terminate timed out, forcing kill...")

            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method4] Force kill succeeded.")
                else:
                    print("[layer1_method4] Force kill failed.")
            else:
                os.kill(pid, signal.SIGKILL)
                print("[layer1_method4] Sent SIGKILL.")

            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method4] Process killed successfully.")
                return 0
            else:
                print("[layer1_method4] Process still alive after force kill.")
                return 1

    except psutil.NoSuchProcess:
        print("[layer1_method4] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method4] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method4] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method4] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method4(pid)
    sys.exit(exit_code)
