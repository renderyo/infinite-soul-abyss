import sys
import os
import ctypes
import psutil
import random
import time
import subprocess
import platform
from ctypes import wintypes

# Setup Windows APIs
kernel32 = ctypes.windll.kernel32
user32 = ctypes.windll.user32

PROCESS_SET_INFORMATION = 0x0200
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_OPERATION = 0x0008
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

CloseHandle = kernel32.CloseHandle

SetPriorityClass = kernel32.SetPriorityClass
SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
SetPriorityClass.restype = wintypes.BOOL

# Priority Classes
PRIORITIES = [
    0x40,   # HIGH_PRIORITY_CLASS
    0x80,   # REALTIME_PRIORITY_CLASS
    0x20,   # ABOVE_NORMAL_PRIORITY_CLASS
    0x10,   # BELOW_NORMAL_PRIORITY_CLASS
    0x40,   # HIGH_PRIORITY_CLASS (again for randomness)
]

def play_sound(filename):
    path = os.path.join(os.path.dirname(__file__), filename)
    system = platform.system()

    try:
        if system == "Windows":
            # Play asynchronously to avoid blocking
            subprocess.Popen([
                "powershell", "-c",
                f"(New-Object Media.SoundPlayer '{path}').Play();"
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif system == "Darwin":
            subprocess.Popen(["afplay", path])
        else:
            # Linux fallback
            try:
                subprocess.Popen(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path])
            except FileNotFoundError:
                try:
                    subprocess.Popen(["aplay", path])
                except FileNotFoundError:
                    print("[Sound Error] No supported player found.")
    except Exception as e:
        print(f"[Sound Error] Failed to play sound: {e}")

def glitch_window_titles(pid):
    # Change window titles repeatedly to glitch UI perception
    try:
        titles = ["System Glitched!", "ISA Corrupting...", "Target Infected", "Loading Chaos..."]
        hwnds = []

        def enum_windows(hwnd, lParam):
            p_id = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(p_id))
            if p_id.value == pid:
                hwnds.append(hwnd)
            return True

        EnumWindowsProto = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows(EnumWindowsProto(enum_windows), 0)

        for _ in range(5):
            for hwnd in hwnds:
                new_title = random.choice(titles)
                user32.SetWindowTextW(hwnd, new_title)
            time.sleep(0.2)
    except Exception:
        pass

def random_priority_fluctuation(proc):
    # Randomly change process priority class multiple times to degrade stability
    try:
        for _ in range(7):
            priority = random.choice(PRIORITIES)
            proc.nice(priority)
            time.sleep(0.15)
    except Exception:
        pass

def force_crash_remote_thread(proc_handle):
    # Inject remote thread to call ExitProcess to force crash
    ExitProcessAddr = kernel32.GetProcAddress(kernel32._handle, b"ExitProcess")
    if not ExitProcessAddr:
        return False

    thread_id = wintypes.DWORD()
    thread_handle = kernel32.CreateRemoteThread(proc_handle, None, 0, ExitProcessAddr, None, 0, ctypes.byref(thread_id))
    if not thread_handle:
        return False

    kernel32.CloseHandle(thread_handle)
    return True

def tampering_and_degradation(pid):
    if not psutil.pid_exists(pid):
        print("[layer2_method9] Process does not exist.")
        return False

    proc = psutil.Process(pid)

    # Open process handle with necessary permissions
    handle = OpenProcess(PROCESS_SET_INFORMATION | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, False, pid)
    if not handle:
        print("[layer2_method9] Failed to open process handle.")
        return False

    print("[layer2_method9] Starting tampering and degradation sequence...")

    # Play death.wav sound on start
    play_sound("death.wav")

    # Glitch window titles (harmless but annoying)
    glitch_window_titles(pid)

    # Randomly fluctuate priority
    random_priority_fluctuation(proc)

    # Try injecting a remote thread to force crash (optional)
    force_crash_remote_thread(handle)

    # Final minor tampering - changing environment variables of process (best effort)
    try:
        env = proc.environ()
        if "PATH" in env:
            env["PATH"] += ";" + os.path.dirname(__file__)
    except Exception:
        pass

    CloseHandle(handle)

    print("[layer2_method9] Tampering and degradation done.")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: layer2_method9.py <pid>")
        sys.exit(1)

    try:
        target_pid = int(sys.argv[1])
    except ValueError:
        print("Invalid PID")
        sys.exit(1)

    success = tampering_and_degradation(target_pid)
    sys.exit(0 if success else 1)
