import sys
import psutil
import os
import signal
import time
import threading
import random

def cpu_stress(duration_sec=5):
    print("[layer1_method7] Starting CPU stress...")
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        for i in range(10000):
            _ = i*i

def memory_stress(iterations=5, size_mb=20):
    print("[layer1_method7] Starting memory stress...")
    blocks = []
    for _ in range(iterations):
        try:
            blocks.append(bytearray(size_mb * 1024 * 1024))  # allocate size_mb MB
            time.sleep(0.5)
        except MemoryError:
            print("[layer1_method7] Memory allocation failed, stopping stress.")
            break
    # Free memory after stress
    blocks.clear()

def affinity_toggler(p, toggle_count=15):
    print("[layer1_method7] Starting CPU affinity toggling...")
    try:
        cpus = list(range(psutil.cpu_count()))
        for _ in range(toggle_count):
            new_affinity = random.sample(cpus, random.randint(1, len(cpus)))
            p.cpu_affinity(new_affinity)
            print(f"[layer1_method7] Set CPU affinity to: {new_affinity}")
            time.sleep(0.3)
    except Exception as e:
        print(f"[layer1_method7] Failed to toggle affinity: {e}")

def dummy_io(p, attempts=10):
    print("[layer1_method7] Starting dummy I/O tampering...")
    try:
        exe_path = p.exe()
        for _ in range(attempts):
            try:
                with open(exe_path, 'rb') as f:
                    f.read(10)
                print("[layer1_method7] Opened and read from executable.")
                time.sleep(0.1)
            except Exception as e:
                print(f"[layer1_method7] File I/O error: {e}")
    except Exception as e:
        print(f"[layer1_method7] Cannot access executable path: {e}")

def layer1_method7(pid):
    print(f"[layer1_method7] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method7] Process found: {p.name()} (PID {pid})")

        # Massive suspend/resume cycles
        try:
            for _ in range(50):
                p.suspend()
                print("[layer1_method7] Process suspended (heavy tampering).")
                time.sleep(0.05)
                p.resume()
                print("[layer1_method7] Process resumed (heavy tampering).")
                time.sleep(0.05)
        except psutil.AccessDenied:
            print("[layer1_method7] Access denied: cannot suspend/resume process.")
        except Exception as e:
            print(f"[layer1_method7] Suspend/resume failed: {e}")

        # Aggressive priority toggling, including realtime on Windows
        try:
            priorities = []
            if os.name == "nt":
                priorities = [
                    psutil.IDLE_PRIORITY_CLASS,
                    psutil.BELOW_NORMAL_PRIORITY_CLASS,
                    psutil.NORMAL_PRIORITY_CLASS,
                    psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                    psutil.HIGH_PRIORITY_CLASS,
                    psutil.REALTIME_PRIORITY_CLASS
                ]
            else:
                priorities = [19, 10, 0, -10, -15, -20]

            for _ in range(3):  # cycle 3 times
                for prio in priorities:
                    try:
                        p.nice(prio)
                        print(f"[layer1_method7] Set priority to {prio}.")
                        time.sleep(0.15)
                    except Exception as e:
                        print(f"[layer1_method7] Failed to set priority {prio}: {e}")
        except Exception as e:
            print(f"[layer1_method7] Priority toggling failed: {e}")

        # Multiple CPU stress threads (5 threads, longer duration)
        stress_threads = []
        for _ in range(5):
            t = threading.Thread(target=cpu_stress, args=(5,))
            t.start()
            stress_threads.append(t)

        # Start memory stress in parallel thread
        mem_thread = threading.Thread(target=memory_stress, args=(10, 30))
        mem_thread.start()

        # CPU affinity toggling rapidly
        affinity_toggler(p, toggle_count=20)

        # Dummy I/O tampering aggressively
        dummy_io(p, attempts=15)

        # Wait all stress threads
        for t in stress_threads:
            t.join()
        mem_thread.join()

        # Repeated termination attempts
        for attempt in range(3):
            print(f"[layer1_method7] Attempting to terminate process (try {attempt+1}/3)...")
            p.terminate()
            try:
                p.wait(timeout=3)
                print("[layer1_method7] Process terminated gracefully.")
                return 0
            except psutil.TimeoutExpired:
                print("[layer1_method7] Graceful terminate timed out, forcing kill...")
                if os.name == "nt":
                    ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                    if ret == 0:
                        print("[layer1_method7] Force kill succeeded.")
                    else:
                        print("[layer1_method7] Force kill failed.")
                else:
                    os.kill(pid, signal.SIGKILL)
                    print("[layer1_method7] Sent SIGKILL.")
                time.sleep(1)
                if not psutil.pid_exists(pid):
                    print("[layer1_method7] Process killed successfully.")
                    return 0
                else:
                    print("[layer1_method7] Process still alive after force kill.")

        print("[layer1_method7] Failed to terminate process after multiple attempts.")
        return 1

    except psutil.NoSuchProcess:
        print("[layer1_method7] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method7] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method7] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method7] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method7(pid)
    sys.exit(exit_code)
