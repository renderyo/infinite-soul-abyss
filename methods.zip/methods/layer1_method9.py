import sys
import psutil
import os
import signal
import time
import threading
import random
import string

def cpu_stress(duration_sec=10):
    print("[layer1_method9] Starting CPU stress...")
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        for i in range(30000):
            _ = i*i

def memory_stress(iterations=20, size_mb=60):
    print("[layer1_method9] Starting memory stress...")
    blocks = []
    for _ in range(iterations):
        try:
            blocks.append(bytearray(size_mb * 1024 * 1024))  # allocate size_mb MB
            time.sleep(0.2)
        except MemoryError:
            print("[layer1_method9] Memory allocation failed, stopping stress.")
            break
    blocks.clear()

def affinity_chaos(p, toggle_count=70):
    print("[layer1_method9] Starting CPU affinity chaos...")
    try:
        cpus = list(range(psutil.cpu_count()))
        for _ in range(toggle_count):
            new_affinity = random.sample(cpus, random.randint(1, len(cpus)))
            p.cpu_affinity(new_affinity)
            print(f"[layer1_method9] Set CPU affinity to: {new_affinity}")
            time.sleep(0.07)
    except Exception as e:
        print(f"[layer1_method9] Failed affinity chaos: {e}")

def dummy_io(p, attempts=50):
    print("[layer1_method9] Starting dummy I/O tampering...")
    try:
        exe_path = p.exe()
        for _ in range(attempts):
            try:
                with open(exe_path, 'rb') as f:
                    f.read(20)
                print("[layer1_method9] Opened and read from executable.")
                time.sleep(0.03)
            except Exception as e:
                print(f"[layer1_method9] File I/O error: {e}")
    except Exception as e:
        print(f"[layer1_method9] Cannot access executable path: {e}")

def thread_flooding(count=100):
    print("[layer1_method9] Starting simulated thread flooding...")

    def dummy_task():
        time.sleep(0.1)

    threads = []
    for _ in range(count):
        t = threading.Thread(target=dummy_task)
        t.start()
        threads.append(t)
        time.sleep(0.005)

    for t in threads:
        t.join()
    print("[layer1_method9] Thread flooding done.")

def insanity_suspend_resume(p, cycles=150):
    print("[layer1_method9] Starting extreme suspend/resume spam...")
    try:
        for _ in range(cycles):
            p.suspend()
            time.sleep(0.02)
            p.resume()
            time.sleep(0.02)
    except psutil.AccessDenied:
        print("[layer1_method9] Access denied: cannot suspend/resume process.")
    except Exception as e:
        print(f"[layer1_method9] Suspend/resume failed: {e}")

def priority_chaos(p, cycles=8):
    print("[layer1_method9] Starting priority chaos...")
    try:
        priorities = []
        if os.name == "nt":
            priorities = [
                psutil.IDLE_PRIORITY_CLASS,
                psutil.BELOW_NORMAL_PRIORITY_CLASS,
                psutil.NORMAL_PRIORITY_CLASS,
                psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                psutil.HIGH_PRIORITY_CLASS,
                psutil.REALTIME_PRIORITY_CLASS
            ]
        else:
            priorities = [19, 10, 0, -10, -15, -20]

        for _ in range(cycles):
            random.shuffle(priorities)
            for prio in priorities:
                try:
                    p.nice(prio)
                    print(f"[layer1_method9] Set priority to {prio}.")
                    time.sleep(0.07)
                except Exception as e:
                    print(f"[layer1_method9] Failed to set priority {prio}: {e}")
    except Exception as e:
        print(f"[layer1_method9] Priority chaos failed: {e}")

def rename_executable_randomly(p):
    print("[layer1_method9] Starting executable renaming...")
    try:
        exe_path = p.exe()
        dir_path = os.path.dirname(exe_path)
        base_ext = os.path.splitext(exe_path)[1]
        for _ in range(10):
            new_name = ''.join(random.choices(string.ascii_letters + string.digits, k=12)) + base_ext
            new_path = os.path.join(dir_path, new_name)
            try:
                if not os.path.exists(new_path):
                    os.rename(exe_path, new_path)
                    print(f"[layer1_method9] Renamed executable to: {new_name}")
                    # Update process info (best effort)
                    exe_path = new_path
                    time.sleep(0.1)
                else:
                    print("[layer1_method9] Generated name exists, skipping rename.")
            except Exception as e:
                print(f"[layer1_method9] Failed to rename executable: {e}")
                break
    except Exception as e:
        print(f"[layer1_method9] Could not access executable path: {e}")

def fake_corruption_files(p):
    print("[layer1_method9] Creating fake corruption files...")
    try:
        exe_path = p.exe()
        dir_path = os.path.dirname(exe_path)
        for i in range(10):
            fake_file = os.path.join(dir_path, f"corrupt_{random.randint(1000,9999)}.bin")
            try:
                with open(fake_file, 'wb') as f:
                    f.write(os.urandom(1024))  # 1 KB random data
                print(f"[layer1_method9] Created fake corruption file: {fake_file}")
                time.sleep(0.05)
            except Exception as e:
                print(f"[layer1_method9] Failed to create fake corruption file: {e}")
    except Exception as e:
        print(f"[layer1_method9] Could not access directory for corruption files: {e}")

def repeated_terminate_kill(p, pid, attempts=10):
    print("[layer1_method9] Starting repeated termination attempts...")
    for attempt in range(attempts):
        print(f"[layer1_method9] Termination attempt {attempt+1}/{attempts}...")
        try:
            p.terminate()
        except Exception as e:
            print(f"[layer1_method9] Terminate failed: {e}")
        try:
            p.wait(timeout=2)
            print("[layer1_method9] Process terminated gracefully.")
            return 0
        except psutil.TimeoutExpired:
            print("[layer1_method9] Graceful terminate timed out, forcing kill...")
            if os.name == "nt":
                ret = os.system(f"taskkill /PID {pid} /F >nul 2>&1")
                if ret == 0:
                    print("[layer1_method9] Force kill succeeded.")
                else:
                    print("[layer1_method9] Force kill failed.")
            else:
                try:
                    os.kill(pid, signal.SIGKILL)
                    print("[layer1_method9] Sent SIGKILL.")
                except Exception as e:
                    print(f"[layer1_method9] SIGKILL failed: {e}")
            time.sleep(1)
            if not psutil.pid_exists(pid):
                print("[layer1_method9] Process killed successfully.")
                return 0
            else:
                print("[layer1_method9] Process still alive after force kill.")
    print("[layer1_method9] Failed to terminate process after repeated attempts.")
    return 1

def layer1_method9(pid):
    print(f"[layer1_method9] Running on PID: {pid}")
    try:
        p = psutil.Process(pid)
        print(f"[layer1_method9] Process found: {p.name()} (PID {pid})")

        # Insane suspend/resume spam
        insanity_suspend_resume = lambda proc, cycles=150: [
            proc.suspend() or time.sleep(0.02) or proc.resume() or time.sleep(0.02)
            for _ in range(cycles)
        ]
        insanity_suspend_resume(p, 150)

        # Priority chaos
        priority_chaos(p, 12)

        # CPU affinity chaos thread
        affinity_thread = threading.Thread(target=affinity_chaos, args=(p, 100))
        affinity_thread.start()

        # CPU stress threads
        cpu_threads = []
        for _ in range(15):
            t = threading.Thread(target=cpu_stress, args=(10,))
            t.start()
            cpu_threads.append(t)

        # Memory stress thread
        mem_thread = threading.Thread(target=memory_stress, args=(30, 60))
        mem_thread.start()

        # Dummy I/O tampering
        dummy_io(p, 60)

        # Thread flooding
        thread_flooding(120)

        # Rename executable repeatedly (best effort, only Windows)
        if os.name == "nt":
            rename_executable_randomly(p)

        # Create fake corruption files
        fake_corruption_files(p)

        # Wait for all threads
        affinity_thread.join()
        for t in cpu_threads:
            t.join()
        mem_thread.join()

        # Repeated termination attempts
        result = repeated_terminate_kill(p, pid, 10)
        return result

    except psutil.NoSuchProcess:
        print("[layer1_method9] Process does not exist (already dead).")
        return 0
    except Exception as e:
        print(f"[layer1_method9] Exception: {e}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("[layer1_method9] No PID provided.")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except ValueError:
        print("[layer1_method9] Invalid PID argument.")
        sys.exit(1)
    exit_code = layer1_method9(pid)
    sys.exit(exit_code)
