import ctypes
import psutil
import time
import random
import win32gui
import win32process
import win32con
import win32security
from ctypes import wintypes

kernel32 = ctypes.windll.kernel32
user32 = ctypes.windll.user32

MB_OK = 0x0
MB_ICONERROR = 0x10

def corrupt_window_text(pid):
    def callback(hwnd, _):
        try:
            _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
            if found_pid == pid:
                glitch_chars = "▒▓█░▄■▲∆¤☠☢⚠️✖️✘✦✧❌❎"
                glitched_title = ''.join(random.choice(glitch_chars) for _ in range(random.randint(40, 70)))
                win32gui.SetWindowText(hwnd, glitched_title)
                rect = win32gui.GetWindowRect(hwnd)
                x = rect[0] + random.randint(-60, 60)
                y = rect[1] + random.randint(-60, 60)
                win32gui.MoveWindow(hwnd, x, y, rect[2]-rect[0], rect[3]-rect[1], True)
        except Exception:
            pass
    try:
        win32gui.EnumWindows(callback, None)
    except Exception:
        pass

def spam_post_messages(pid):
    try:
        hwnds = []
        def enum_hwnd(hwnd, _):
            if win32gui.IsWindowVisible(hwnd):
                _, check_pid = win32process.GetWindowThreadProcessId(hwnd)
                if check_pid == pid:
                    hwnds.append(hwnd)
        win32gui.EnumWindows(enum_hwnd, None)
        msgs = [
            win32con.WM_CLOSE,
            win32con.WM_ENABLE,
            win32con.WM_SYSCOMMAND,
            win32con.WM_KEYDOWN,
            win32con.WM_KEYUP,
            win32con.WM_LBUTTONDOWN,
            win32con.WM_LBUTTONUP,
            win32con.WM_SETFOCUS,
            win32con.WM_KILLFOCUS,
            win32con.WM_ACTIVATE,
            win32con.WM_CANCELMODE,
            win32con.WM_SETCURSOR,
        ]
        for hwnd in hwnds:
            for _ in range(25):  # More spam, but still not too fast
                msg = random.choice(msgs)
                win32gui.PostMessage(hwnd, msg, 0, 0)
                time.sleep(0.005)
    except Exception:
        pass

def break_focus(pid):
    try:
        def enum_windows(hwnd, _):
            try:
                _, target_pid = win32process.GetWindowThreadProcessId(hwnd)
                if target_pid == pid:
                    for _ in range(6):  # More toggle cycles
                        win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                        win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
                        win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                        time.sleep(0.02)
                    win32gui.SetForegroundWindow(hwnd)
            except Exception:
                pass
        win32gui.EnumWindows(enum_windows, None)
    except Exception:
        pass

def remove_process_tokens(proc):
    try:
        token = win32security.OpenProcessToken(proc.handle, win32con.TOKEN_ALL_ACCESS)
        for _ in range(6):  # More attempts to corrupt privileges
            try:
                win32security.AdjustTokenPrivileges(token, False, [])
            except Exception:
                pass
            time.sleep(0.02)
        return True
    except Exception:
        return False

def debugger_loop(pid):
    DebugActiveProcess = kernel32.DebugActiveProcess
    DebugActiveProcess.argtypes = [ctypes.c_ulong]
    DebugActiveProcess.restype = ctypes.c_bool
    DebugActiveProcessStop = kernel32.DebugActiveProcessStop
    DebugActiveProcessStop.argtypes = [ctypes.c_ulong]
    DebugActiveProcessStop.restype = ctypes.c_bool

    try:
        for _ in range(10):  # Double loops
            if DebugActiveProcess(pid):
                time.sleep(0.1)
                DebugActiveProcessStop(pid)
                time.sleep(0.1)
    except Exception:
        pass

def show_error_dialogs(pid):
    def callback(hwnd, _):
        try:
            _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
            if found_pid == pid:
                title = "Critical Error"
                message = "A fatal error has occurred.\n\nProcess will close."
                user32.MessageBoxW(hwnd, message, title, MB_OK | MB_ICONERROR)
        except Exception:
            pass
    try:
        win32gui.EnumWindows(callback, None)
    except Exception:
        pass

def force_terminate(proc):
    try:
        # Using TerminateProcess WinAPI for stronger kill
        HANDLE = wintypes.HANDLE(proc.handle)
        if kernel32.TerminateProcess(HANDLE, 1):
            proc.wait(timeout=1)
            return True
        return False
    except Exception:
        return False

def run(pid):
    try:
        proc = psutil.Process(pid)
    except Exception:
        print(f"[layer2_method3] Process {pid} not found.")
        return False

    print(f"[layer2_method3] Executing OVERPOWERED glitch on PID {pid}!")

    corrupt_window_text(pid)
    spam_post_messages(pid)
    break_focus(pid)
    remove_process_tokens(proc)
    debugger_loop(pid)
    show_error_dialogs(pid)
    time.sleep(0.3)

    if force_terminate(proc):
        print("[layer2_method3] Process force-terminated successfully!")
        return True

    # Fallback to psutil kill
    try:
        proc.kill()
        proc.wait(timeout=1)
        print("[layer2_method3] Process killed successfully!")
        return True
    except Exception:
        print("[layer2_method3] Failed to kill process.")
        return False

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: layer2_method3.py <pid>")
        sys.exit(1)
    try:
        pid = int(sys.argv[1])
    except Exception:
        print("Invalid PID")
        sys.exit(1)
    run(pid)
